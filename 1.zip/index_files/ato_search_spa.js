//build: Wed Apr 24 2019 13:00:00 GMT+1100 (AUS Eastern Daylight Time): fix legaldb filter GA tracking issue
//build: Tue Apr 20 2018 13:00:00 GMT+1100 (AUS Eastern Daylight Time): fix faceted search result count inconsistent issue.
//build: Tue Apr 15 2018 15:15:00 GMT+1100 (AUS Eastern Daylight Time): fix faceted search result count inconsistent issue.
//build: Tue Jan 17 2018 15:46:00 GMT+1100 (AUS Eastern Daylight Time): fix faceted search result count inconsistent issue. fix filter doesn't reset to 'All' when legaldb is selected
//build: Tue Jan 10 2018 15:40:00 GMT+1100 (AUS Eastern Daylight Time): Facted Search (CR): show results in all filter is users change search term / only show ATO Recommends and Quicklinks only in the All Filter and not for other filters
//build: Tue Jan 05 2018 17:02:00 GMT+1100 (AUS Eastern Daylight Time): bugfixing for filter in Facted search
//build: Tue Nov 06 2017 11:52:00 GMT+1100 (AUS Eastern Daylight Time): remove duplicated filter name
//build: Tue Oct 06 2017 11:52:00 GMT+1100 (AUS Eastern Daylight Time): remove date filter for banner search / remove 1006 for other filters
//build: Tue Sep 07 2017 13:08:00 GMT+1100 (AUS Eastern Daylight Time): change ato.spa.search.upadteSearchBoxUI to empty to fix mobile UI issue
//build: Fri Dec 25 2016 09:50:00 GMT+1100 (AUS Eastern Daylight Time): remove date filter for Faceted search
//build: Mon Nov 25 2016 13:50:00 GMT+1100 (AUS Eastern Daylight Time): show filter counts
//build: Mon Nov 02 2016 15:30:00 GMT+1100 (AUS Eastern Daylight Time): enabled Faceted search(A/B Testing)
//build: Mon Oct 04 2016 14:30:00 GMT+1100 (AUS Eastern Daylight Time): add functions for ato_tax_calculator page render with SPA widget 
//build: Mon Aug 15 2016 14:49:00 GMT+1100 (AUS Eastern Daylight Time): fix banner search show empty page if search term is empty
//build: Tue Aug 01 2016 10:12:00 GMT+1100 (AUS Eastern Daylight Time): add ato_tax_calculator
//build: Wed Jul 13 2016 12:00:00 GMT+1100 (AUS Eastern Daylight Time): fix search page broken issue with no search term
//build: Mon Jul 04 2016 11:12:00 GMT+1100 (AUS Eastern Daylight Time): show message and display when the filter is switched to ALL years when no results are found under current year/no message displayed if still no result
//build: Wed Jun 29 2016 10:22:00 GMT+1100 (AUS Eastern Daylight Time): rename namespace for ga functions
//build: Wed Jun 22 2016 13:10:00 GMT+1100 (AUS Eastern Daylight Time): enable google analytics
//build: Wed Jun 15 2016 17:45:00 GMT+1100 (AUS Eastern Daylight Time): remove date filter is no result,automatically
//build: Wed Mar 31 2016 16:45:00 GMT+1100 (AUS Eastern Daylight Time): fix date filter issue, date filter will be applied when do banner search
//build: Wed Mar 09 2016 16:45:00 GMT+1100 (AUS Eastern Daylight Time): store parameters in hash tag for banner search
//build: Fri Feb 12 2016 15:45:00 GMT+1100 (AUS Eastern Daylight Time): create setGSAFilter to set gsa filter flag
//build: Mon Jan 11 2016 11:30:00 GMT+1100 (AUS Eastern Daylight Time): navigate to result page for QC search if only one result found and do not show result page in this case
//build: Wed Jan 06 2015 11:30:00 GMT+1100 (AUS Eastern Daylight Time): bug fixing for banner search-do redirect if only one result for QC search.
//build: Tue Jan 05 2015 10:50:00 GMT+1100 (AUS Eastern Daylight Time): support media centre search
//build: Tue Dec 17 2015 10:38:00 GMT+1100 (AUS Eastern Daylight Time): support calculators and tool search/Tax rates and codes search/print publication search with defined terms
//build: Wed Dec 09 2015 17:36:00 GMT+1100 (AUS Eastern Daylight Time): support calculators and tool search/Tax rates and codes search/print publication search
//build: Thu Dec 08 2015 17:00:00 GMT+1100 (AUS Eastern Daylight Time): navigate to result page for QC search if only one result found
//build: Thu Oct 20 2015 18:08:00 GMT+1100 (AUS Eastern Daylight Time): strip out page=x for NAT/QC search, bugfixing for banner search
//build: Thu Oct 19 2015 17:18:00 GMT+1100 (AUS Eastern Daylight Time): strip out page=x for NAT/QC search
//build: Wed Oct 14 2015 16:14:00 GMT+1100 (AUS Eastern Daylight Time): fix defect 1229:Social Media - clicking on a hyperlink in the search results description for Facebook and LinkedIn does not open new window/tab
//build: Thu Sep 17 2015 16:37:00 GMT+1100 (AUS Eastern Daylight Time): show youtube in new tab, not popup
//build: Thu Aug 27 2015 16:29:00 GMT+1100 (AUS Eastern Daylight Time): Expanded form Search Terms
//build: Mon Aug 17 2015 16:29:00 GMT+1100 (AUS Eastern Daylight Time): fix 'New and Update' month check issue
//build: Tue Aug 04 2015 17:50:00 GMT+1100 (AUS Eastern Daylight Time): enable suggest for mobile version/fix 'Search for ' issue for main search field
//build: Fri Jul 31 2015 13:01:00 GMT+1100 (AUS Eastern Daylight Time): Social medial content display with ATO html
//build: Thu Jul 30 2015 16:01:00 GMT+1100 (AUS Eastern Daylight Time): Social medial content display is ready
//build: Wed Jul 28 2015 11:40:00 GMT+1100 (AUS Eastern Daylight Time): Add Form Search/ACN/ABN search
//build: Wed Jul 22 2015 17:13:00 GMT+1100 (AUS Eastern Daylight Time): use dropdown for filters-UI enhancement to avoiding showing first option
//build: Wed Jul 21 2015 14:01:00 GMT+1100 (AUS Eastern Daylight Time): use dropdown for filters.
//build: Wed Jun 11 2015 15:08:00 GMT+1100 (AUS Eastern Daylight Time): bug fixing for exclude search
//build: Wed Jun 10 2015 23:18:00 GMT+1100 (AUS Eastern Daylight Time): change 'update' text and add ALT text/show breadcrumbs for keymatch
//build: Wed Jun 02 2015 14:00:00 GMT+1100 (AUS Eastern Daylight Time): 2-BR Allow Reserved Search Terms/Characters UI change;29-U Differentiate new and Updated Content
//build: This May 28 2015 14:11:00 GMT+1100 (AUS Eastern Daylight Time): L2 Fix only
//build: Wed May 27 2015 14:11:00 GMT+1100 (AUS Eastern Daylight Time):  fix legaldb search
//build: Wed May 27 2015 12:05:00 GMT+1100 (AUS Eastern Daylight Time):  change logic to fix 'repeat search for omitted result'
//build: Thu May 21 2015 16:10:00 GMT+1100 (AUS Eastern Daylight Time): fix date filter issue which generates different results for banner search and search page/comment filter number query
//build: Thu Apr 28 2015 17:30:00 GMT+1100 (AUS Eastern Daylight Time): remove filter for empty query to make sure no result return
//build: Thu Apr 27 2015 17:50:00 GMT+1100 (AUS Eastern Daylight Time): for QC/NAT search, avoid wrong empty q check message
//build: Thu Apr 23 2015 11:27:00 GMT+1100 (AUS Eastern Daylight Time): for QC/NAT search, only meta tag will be used, the search term will be set to empty
//build: Thu Feb 21 2015 10:00:00 GMT+1100 (AUS Eastern Daylight Time): Changes made to add All option in the dropdown filter
//build: Thu Apr 16 2015 13:11:00 GMT+1100 (AUS Eastern Daylight Time): Set Cookie to capture search term for pop-up/feedback survey
//build: Thu Feb 16 2015 13:24:00 GMT+1100 (AUS Eastern Daylight Time): add parameter ato_search_description_meta_tag to show snippet from metatag
//build: Thu Feb 12 2015 14:01:00 GMT+1100 (AUS Eastern Daylight Time): fix segment market search issue for banner search/filter display for banner search if segment is checked
//build: Thu Feb 11 2015 17:22:05 GMT+1100 (AUS Eastern Daylight Time): fix segment market search issue for banner search
//build: Thu Feb 11 2015 17:01:05 GMT+1100 (AUS Eastern Daylight Time): fix QC search issue
//build: Thu Feb 09 2015 17:01:05 GMT+1100 (AUS Eastern Daylight Time): remove the last item of breadcrumbs
//build: Thu Feb 06 2015 14:56:05 GMT+1100 (AUS Eastern Daylight Time): show date filter for current and Previous Years
//build: Thu Feb 06 2015 12:02:05 GMT+1100 (AUS Eastern Daylight Time): fixed twice error message issue
//build: Thu Feb 04 2015 17:50:05 GMT+1100 (AUS Eastern Daylight Time): change breadcrumbs/add advanced search
//build: Thu Feb 03 2015 11:40:05 GMT+1100 (AUS Eastern Daylight Time): Fixed legal db search issue for banner search
//build: Thu Jan 29 2015 10:50:05 GMT+1100 (AUS Eastern Daylight Time): add event tracking for filter/date_filter/result click/recommendation click/quick link/cluster/pagin; change spinning wheel background color to white to make it looks better on IE8
//version 20150128-1500 fix suggest display issue on firefox and IE
//version 20150123-1600 encode url for event tracking/show top when clicks page navigation
//version 20150123-1000 change filter html structure/add spinning wheel
//version 20150122-1620 support EventTracking
//js functions to handle global parameters for search. Previously, they are managed in the backend
var ato = ato || {}; //define namespace
ato.spa = ato.spa || {};
(function () {
    ato.spa.search = ato.spa.search || {};
    //Messages
    ato.spa.search.messages = ato.spa.search.messages || {};

    //TFN warning message
    ato.spa.search.messages.TFN_ERROR = "Sorry, but we are unable to complete your search - it possibly included personal info, such as your tax file number.\nTry searching again and be sure not to enter any personal info.";

    ato.spa.search.is_auto_search_for_date_filter = false;

    //All global parames which will be used in xslt
    //for QC search
    var pn_dc_terms_identifier = 'dc_terms_identifier';
    //for NAT search
    var pn_dc_terms_natnumber = 'dc_terms_natnumber';
    //
    var pn_dc_terms_ato_gsa_code = 'dc_terms_ato_gsa_code';
    var pn_gsa_searchable = 'gsa_searchable';
    var pn_dc_terms_dc_date_filter = 'dc_terms_dc_date_filter';
    var pn_ato_home = 'ato_home';
    var pn_general_id = 'general_id';
    var pn_exclude_general = 'exclude_general';
    var pn_criteria_error_message = 'criteria_error_message';
    var pn_legal_nonindexed = 'legal_nonindexed';
    var pn_legal_searchable = 'legal_searchable';
    var pn_market_segment_short = 'market_segment_short';
    var pn_market_segment = 'market_segment';
    var pn_market_label = 'market_label';
    var pn_no_search_criteria = 'no_search_criteria';
    var pn_atogov_dns = 'atogov_dns';
    var pn_legal_dns = 'legal_dns';
    var pn_search_tips_url = 'search_tips_url';
    var pn_results_page_url = 'results_page_url';
    var pn_advanced_page_url = 'advanced_page_url';
    var pn_market_segment_list = 'market_segment_list';
    var pn_atogov_collection = 'atogov_collection';
    var pn_legaldb_collection = 'legaldb_collection';


    ato.spa.search.globalParams = [pn_dc_terms_identifier, pn_dc_terms_natnumber, pn_dc_terms_ato_gsa_code,
	                               pn_gsa_searchable, pn_dc_terms_dc_date_filter, pn_ato_home, pn_general_id,
	                               pn_exclude_general, pn_criteria_error_message, pn_legal_nonindexed, pn_legal_searchable,
	                               pn_market_segment_short, pn_market_segment, pn_market_label, pn_no_search_criteria,
	                               pn_atogov_dns, pn_legal_dns, pn_search_tips_url, pn_results_page_url, pn_advanced_page_url,
	                               pn_market_segment_list, pn_atogov_collection, pn_legaldb_collection];

    //Constants
    ato.spa.search.constants = ato.spa.search.constants || {};
    //QC metatag
    ato.spa.search.constants.DCTERMS_Identifier = "DCTERMS_identifier";
    //NAT metatag
    ato.spa.search.constants.DCTERMS_NATNumber = "ato_reference_natNumber";
    //Collection filter for GSA
    ato.spa.search.constants.DCTERMS_AtoGSACode = "ato_gsacode";
    //Date filter for GSA metatag
    ato.spa.search.constants.DCTERMS_DcDateFilter = "dc_date_filter";
    //default market segment
    ato.spa.search.constants.ATO_HOME = "ATO_Home";

    ato.spa.search.constants.hour_glass_div = "hourGlass";

    ato.spa.search.constants.GSA_ADVISED_LINKS_DIV_ID = "gsa_advised_link_div";
    ato.spa.search.constants.GSA_ADVISED_SPACE_TERM = "gsaShowNAT";
    ato.spa.search.constants.GSA_ADVISED_LINK_EXCLUDE_ID = "gsaExcludingNAT";
    ato.spa.search.constants.GSA_SEARCH_RESULT_CSS = 'searchResult';

    //URL parameters
    ato.spa.search.constants.QC_NAT_ORIG_QUERY_PARAM = "qn_orig_q";
    ato.spa.search.constants.BANNER_SEARCH_PARAM = "banner_search";
    //used for filter
    ato.spa.search.constants.ato_filter_class = 'ato_filter'//'ato_filter';
    ato.spa.search.constants.ato_filter_current_class = 'current';
    ato.spa.search.constants.ato_dateFilter_class = 'ato_date_filter';
    ato.spa.search.constants.ato_breadcrumbs_class = 'breadcrumbs';
    ato.spa.search.constants.ato_date_class = 'date';
    ato.spa.search.constants.ato_filter_legal_db_id = 'filter_legal_db';
    ato.spa.search.constants.ato_filter_label_id = 'filter_label';
    ato.spa.search.constants.ato_date_filter_label_id = 'date_filter_label';


	//search box
	ato.spa.search.constants.ato_gsa_search_box_div_id = 'ato_gsa_search_box';
	//faceted search
	ato.spa.search.constants.ato_filter_desktop_class = 'ato_filter_desktop';
	ato.spa.search.constants.ato_filter_video_id = 'filter_videos';

    //form search
    ato.spa.search.constants.ato_form_search_reg = /^(form|forms|forms downloads|forms and publications|forms Australian taxation office|forms ato|forms and instructions|ato forms|ato forms and instructions|ato form|ato forms download)$/i;
    ato.spa.search.constants.ato_form_search_div_id = 'form_search_div';
    ato.spa.search.constants.ato_form_search_bt_id = 'ato_form_search_bt';
    ato.spa.search.constants.ato_form_search_query_id = 'form_search_query';
    ato.spa.search.constants.ato_form_search_site_filter_id = 'form_search_site_filter';
    ato.spa.search.constants.ato_form_search_year_filter_id = 'form_search_year_filter';


    //ABN/ACN search
    ato.spa.search.constants.ato_show_ABN_ACN_reg = /^(ABN|ABN lookup|ABN regular expression|ABN search|ACN|ACN number|ACN lookup)|ACN regular expression|Search for ABN|Search ABN$/i;
    ato.spa.search.constants.ato_ABN_search_div_id = 'ABN_ACN_search_div';
    ato.spa.search.constants.ato_ABN_ACN_search_bt_id = 'ato_ABN_ACN_search_bt';
    ato.spa.search.constants.ato_ABN_ACN_search_query_id = 'ABN_ACN_query';



    //calculators and tools search
    ato.spa.search.constants.ato_ct_search_reg = /^(Calculator|Calculators|Calculate your tax|Calculate your tax rate|Calculate my tax|Calculating tax)$/i;
    ato.spa.search.constants.ato_ct_search_div_id = 'calc_tool_search_div';
    ato.spa.search.constants.ato_ct_search_bt_id = 'ato_calc_tool_search_bt';
    ato.spa.search.constants.ato_ct_search_query_id = 'calc_tool_search_query';
    ato.spa.search.constants.ato_ct_search_site_filter_id = 'calc_tool_search_site_filter';
    ato.spa.search.constants.ato_ct_search_year_filter_id = 'calc_tool_search_year_filter';


    //tax rates and codes search
    ato.spa.search.constants.ato_trc_search_reg = /^(Tax rate|Tax rates|Tax rate sheet|Tax rates sheet|Tax rate table|Tax rates tables|Tax table|Tax tables|Tax schedule|Tax schedules|Ready reckoner)$/i;
    ato.spa.search.constants.ato_trc_search_div_id = 'trc_search_div';
    ato.spa.search.constants.ato_trc_search_bt_id = 'ato_trc_search_bt';
    ato.spa.search.constants.ato_trc_search_query_id = 'trc_search_query';
    ato.spa.search.constants.ato_trc_search_site_filter_id = 'trc_search_site_filter';
    ato.spa.search.constants.ato_trc_search_year_filter_id = 'trc_search_year_filter';

    //Print publications search
    ato.spa.search.constants.ato_pp_search_reg = /^(Print|Printing|Printable|Order publications)$/i;
    ato.spa.search.constants.ato_pp_search_div_id = 'pp_search_div';
    ato.spa.search.constants.ato_pp_search_bt_id = 'ato_pp_search_bt';
    ato.spa.search.constants.ato_pp_search_query_id = 'pp_search_query';
    ato.spa.search.constants.ato_pp_search_site_filter_id = 'pp_search_site_filter';
    ato.spa.search.constants.ato_pp_search_year_filter_id = 'pp_search_year_filter';

    //Media cnetre search
    ato.spa.search.constants.ato_mc_search_reg = /^(Media release|Media releases|Media centre|Media unit|Media room|Articles|Tax articles)$/i;
    ato.spa.search.constants.ato_mc_search_div_id = 'mc_search_div';
    ato.spa.search.constants.ato_mc_search_bt_id = 'ato_mc_search_bt';
    ato.spa.search.constants.ato_mc_search_query_id = 'mc_search_query';
    ato.spa.search.constants.ato_mc_search_year_filter_id = 'mc_search_year_filter';

	//social media
    ato.spa.search.constants.ato_date_social_class = 'ato_social_date';

    //youtube
    ato.spa.search.constants.ato_video_link_class = 'searchResult_videourl';
    ato.spa.search.constants.ato_video_iframe_class = 'searchResult_video-player';

	ato.spa.search.constants.spa_widget_div_id = "applicationHost";
	ato.spa.search.constants.spa_tax_calculator_div_id = "ato_tax_calculator_container";

    ato.spa.search.current_filter = '';
    ato.spa.search.current_dateFilter = '';
    ato.spa.search.current_site = '';
    ato.spa.search.current_dateFilterValue = 'c'; //default is current
    ato.spa.search.firstLoad = true;
    ato.spa.search.set_filter_from_hash = false;

    //result display
    ato.spa.search.summary_link_css = "summary_link";
    ato.spa.search.summary_link_img_css = "summary_link_img";

    //get all values for these global parameters which were managed in vb.net
    ato.spa.search._getConfigValue = function (key){
        return ato.spa.config.getConfigValue(key);


	}

    ato.spa.search._getGeneralId = function (){
        return ato.spa.config.marketSegmentLookup('General');
    };
    ato.spa.search.appendParamForBannerSearch = function (url){
        var temp = ato.spa.gsa.getParameterByName(ato.spa.search.constants.QC_NAT_ORIG_QUERY_PARAM);
        if (temp != null && temp.length > 0){
            url += "&" + ato.spa.search.constants.QC_NAT_ORIG_QUERY_PARAM + "=" + temp;
        }
        return url;
    }
    ato.spa.search._getMS = function (url) {
        //get the ms from http request
        var ms = ato.spa.gsa.getParameterByName('ms', url);
        if (ms == '' || ms == 'undefined') {
            //get from the top box
            ms = ato.spa.GSAManager.getMSInTop();
            if (ms == '' || ms == 'undefined') {
                ms = ato.spa.search.constants.ATO_HOME; //default value
            }
		}

        return ms;


	};
    // this function should be called for each search related action
    // to find out which search field is current active.
    //This method is from ATO team.
    ato.spa.search.getActiveSearchBar = function () {
        // the search bar in the mobile popup header
        var headerPopupSearch = $('.header-popup.on').find('.search');

        // the search bar along side with Logo
        var mainBarSearch = $('.main-bar').find('.search');

        // the search bar on the Search result page
        var mainSearch = $('.atoSearch').find('.searchBar');

        // the mobile popup search is active
        if (headerPopupSearch.length > 0) return headerPopupSearch;

        // search on the desktop view
        if (mainBarSearch.length > 0) return mainBarSearch;

        // on search result page
        return mainSearch;
    }//getActiveSearchBar

    ato.spa.search.isMobileView = function () {
        return $(window).width() <= 768;
    };

    ato.spa.search.getBannerSearchField = function () {

        var searchDiv = ato.spa.search.getActiveSearchBar();

        var fieldInDiv = $(searchDiv).find('input[type=text]');

        //Top search box
        var GSA_TOP_SEARCH_FIELD_ID = "txt_banner_field";
        if (fieldInDiv.length > 0) {
            return fieldInDiv;
        } else {
            return $("#" + GSA_TOP_SEARCH_FIELD_ID);
        }


    }//getActiveSearchBar


    ato.spa.search._getMarketSegmentList = function () {
        return ato.spa.config.MarketSegmentList;
    };

    ato.spa.search._getMSLabel = function (ms) {
        return ato.spa.config.marketSegmentLookup(ms);
    };


    ato.spa.search._getMarketsThatExcludeGeneral = function () {
        var temp = ato.spa.search._getMarketSegmentList().split(',');
        var general = ato.spa.search._getGeneralId();
        var result = new Array();
        for (var i = 0; i < temp.length; i++) {
            if (temp[i] != general) {
                result.push(temp[i]);
            }
        }
        return result.join(',');
    };
    ato.spa.search.buildGlobalParamsForURL = function (q, currentURL) {
        var params = ato.spa.search.buildGlobalParams(q, currentURL);
        var result = '';
        for (var i = 0; i < ato.spa.search.globalParams.length; i++) {
            if (i > 0) {
                result += "&";
            }
            var name = ato.spa.search.globalParams[i];
            var value = params[name];
            if (value == 'undefined' || value == null) {
                value = '';
            }
            result += name + "=" + ato.spa.GSAManager.htmlEncode(value);
        }

        return result;
    };

    ato.spa.search.setGSAFilter = function (currentURL) {
        var result = currentURL;
        //check if the current site is legal db..
        var legaldbSite = ato.spa.config.getConfigValue(pn_legaldb_collection);
        var currentSite = ato.spa.gsa.getParameterByNameInURL('site', currentURL);
        var currentFilter = ato.spa.gsa.getParameterByNameInURL('filter', currentURL);
        var defaultFilterForLegalDB = 'p';
        var defauttFilterForOthers = '1';
        //if it is legal db site and filter is not 0, set the filter to 'p'
        if (currentSite == legaldbSite) {
            if (currentFilter == null || currentFilter == '') {
                result += "&filter=" + defaultFilterForLegalDB;
            } else if (currentFilter == '1') {
                result = ato.spa.search.replaceParamInURL(currentURL, "filter", defaultFilterForLegalDB);
            }
        } else {
            if (currentFilter == 'p') {
                result = ato.spa.search.replaceParamInURL(currentURL, "filter", defauttFilterForOthers);
            }
        }
        return result;


    };

    ato.spa.search.buildGlobalParams = function (q, currentURL) {
        var result = new Array();
        result[pn_dc_terms_identifier] = ato.spa.search.constants.DCTERMS_Identifier;
        result[pn_dc_terms_natnumber] = ato.spa.search.constants.DCTERMS_NATNumber;
        result[pn_dc_terms_ato_gsa_code] = ato.spa.search.constants.DCTERMS_AtoGSACode;

        //		.Add("gsa_searchable", GetConfigValue(WIDGETS_GSA_SEARCHABLE, WIDGETS_SITESEARCH_CONFIG))
        result[pn_gsa_searchable] = ato.spa.search._getConfigValue(pn_gsa_searchable);

        result[pn_dc_terms_dc_date_filter] = ato.spa.search.constants.DCTERMS_DcDateFilter;
        result[pn_ato_home] = ato.spa.search.constants.ATO_HOME;
        result[pn_general_id] = ato.spa.search._getGeneralId();
        result[pn_exclude_general] = ato.spa.search._getMarketsThatExcludeGeneral();

        //		.Add("criteria_error_message", GetConfigValue(WIDGETS_SEARCH_CRITERIA_WARNING, WIDGETS_SITESEARCH_CONFIG))
        result[pn_criteria_error_message] = ato.spa.search._getConfigValue(pn_criteria_error_message);
        //		.Add("legal_nonindexed", GetConfigValue(LEGAL_NONNDEXED, WIDGETS_SITESEARCH_CONFIG))
        result[pn_legal_nonindexed] = ato.spa.search._getConfigValue(pn_legal_nonindexed);

        //		"legal_searchable", GetConfigValue(LEGAL_SEARCHABLE, WIDGETS_SITESEARCH_CONFIG
        result[pn_legal_searchable] = ato.spa.search._getConfigValue(pn_legal_searchable);

        //		MarketSegment = Page.Request.QueryString("ms")
        var MarketSegment = ato.spa.search._getMS(currentURL);
        var marketLabel = ato.spa.search._getMSLabel(MarketSegment);
        result[pn_market_segment_short] = MarketSegment;
        result[pn_market_segment] = MarketSegment;
        result[pn_market_label] = ato.spa.search._getMSLabel(MarketSegment);
        var noSearchCriteria = false;
        if (q == '' || q == 'undefined') {
            noSearchCriteria = true;
        }
        result[pn_no_search_criteria] = noSearchCriteria
        //        .Add("atogov_dns", GetConfigValue(WIDGETS_ATO_GOV_DNS, WIDGETS_SITESEARCH_CONFIG)
        result[pn_atogov_dns] = ato.spa.search._getConfigValue(pn_atogov_dns);

        //        .Add("legal_dns", GetConfigValue(WIDGETS_LEGAL_DNS_CONFIG, WIDGETS_SITESEARCH_CONFIG))
        result[pn_legal_dns] = ato.spa.search._getConfigValue(pn_legal_dns);

        //		Dim searchTipsUrl As String = GetConfigValue(WIDGETS_SEARCH_TIPS_PAGE, WIDGETS_SITESEARCH_CONFIG)
        //        Dim advancedPageUrl As String = GetConfigValue(WIDGETS_ADVANCED_SEARCH_PAGE, WIDGETS_SITESEARCH_CONFIG
        //        Dim resultsPageUrl As String = GetConfigValue(WIDGETS_RESULTS_PAGE, WIDGETS_SITESEARCH_CONFIG

        result[pn_search_tips_url] = ato.spa.search._getConfigValue(pn_search_tips_url);
        result[pn_results_page_url] = ato.spa.search._getConfigValue(pn_results_page_url);
        result[pn_advanced_page_url] = ato.spa.search._getConfigValue(pn_advanced_page_url);
        result[pn_market_segment_list] = ato.spa.search._getMarketSegmentList();

        //		Private _Collection As String = GetConfigValue(WIDGETS_ATO_GOV_COLLECTION, WIDGETS_SITESEARCH_CONFIG)
        //         .Add("atogov_collection", _Collection)
        result[pn_atogov_collection] = ato.spa.search._getConfigValue(pn_atogov_collection);
        //         .Add("legaldb_collection", GetConfigValue(WIDGETS_LEGAL_DATABASE_COLLECTION, WIDGETS_SITESEARCH_CONFIG)
        result[pn_legaldb_collection] = ato.spa.search._getConfigValue(pn_legaldb_collection);

        return result;
    };

    ato.spa.search.hasTFN = function (q) {
        if (q == null) {
            return false;
        }
        var numberPattern = /\d+/g;
        var tempArray = q.match(numberPattern);
        if (tempArray != null) {
            for (var i = 0; i < tempArray.length; i++) {
                if (ato.spa.search.isTFN(tempArray[i])) {
                    return true;
                }
            }
		}
        return false;
    };
    ato.spa.search.updateResultLink = function () {
        //for QC/NAT search
        var dcIdentifier = ato.spa.search.constants.DCTERMS_Identifier;
        var dcNatNumber = ato.spa.search.constants.DCTERMS_NATNumber;
        if (_isNatOrQCSearch(dcIdentifier, dcNatNumber)){
            //
            $("." + ato.spa.search.constants.GSA_SEARCH_RESULT_CSS + " a").each(function () {
                var hrefOrig = $(this).attr("href");
                var hrefNew = hrefOrig.replace(/&page=(\d)+/i, '');
                hrefNew = hrefNew.replace(/\?page=(\d)+&/i, '?');
                hrefNew = hrefNew.replace(/\?page=(\d)+/i, '?');
                $(this).attr("href", hrefNew);
            });
        }

    };
    ato.spa.search.doBannerSearch = function (q) {
        ATO_SiteSearch.query = q;
        ATO_SiteSearch.origQuery = q;
        //InitialiseStringBldr
        InitialiseStringBldrs();

        var sm = ato.spa.GSAManager.getMSInTop();
        ATO_SiteSearch.strMarketSegment = sm;
        ATO_SiteSearch.site = ato.spa.config.getDefaultSite();
        if (ATO_SiteSearch.strMarketSegment == ato.spa.search.constants.ATO_HOME) {//only search legal databas
            ATO_SiteSearch.site = ato.spa.search._getConfigValue(pn_legaldb_collection);
        }
        var smLabel = ato.spa.config.marketSegmentLookup(sm);
        if (smLabel == '' || smLabel == null) {
            ATO_SiteSearch.strMarketSegment = ato.spa.search.constants.ATO_HOME;
        }

        //use configuration to get result page for top search
        var resultPage = ato.spa.config.getSearchPage();
        var dcIdentifier = ato.spa.search.constants.DCTERMS_Identifier;
        var dcNatNumber = ato.spa.search.constants.DCTERMS_NATNumber;
        var dcDateFilter = ato.spa.search.constants.DCTERMS_DcDateFilter;
        var primaryCollection = ato.spa.search._getConfigValue(pn_atogov_collection);
        var primarySearchable = ato.spa.search._getConfigValue(pn_gsa_searchable);
        var secondarySearchable = ato.spa.search._getConfigValue(pn_legal_nonindexed) + '.' + ato.spa.search._getConfigValue(pn_legal_searchable);
        IsNatOrQCSearch(dcNatNumber, dcIdentifier);
        //DetermineSearchYears(dcDateFilter);
        FormatRequiredField(primaryCollection, primarySearchable, secondarySearchable);
        BuildUrl(resultPage);
        var bannerSearchUrl = ato.spa.search.appendGetfields(ATO_SiteSearch.url.toString());
        //window.location = bannerSearchUrl;
        //use hash tag
        var tempArray = bannerSearchUrl.split("?");
        var baseUrl = ato.spa.config.getSearchPage();
        bannerSearchUrl = bannerSearchUrl + "&" + ato.spa.search.constants.BANNER_SEARCH_PARAM + "=1";
        var hashValue = ato.spa.gsa.Base64.encode(bannerSearchUrl);
        //window.location = baseUrl + "#" + hashValue;
        var aliasnameforSearch = ato.spa.config.getAliasName();
        window.location = aliasnameforSearch + "#" + hashValue;
    }
    ato.spa.search.isSearchLoadUrl = function (url) {
        if (url == null || url == '') {
            return false;
        }
        var searchRootPage = ato.spa.config.getSearchPage();
        return url.indexOf(searchRootPage) == 0;
    };

    ato.spa.search.isInt = function (n) {
        try {
            return $.isNumeric(n) && Number(n) % 1 === 0;
        } catch (e) {
            return false;
        }

    }

    ato.spa.search.isTFN = function (strTFNnumber) {
        var maxTFNLength = 9
        var strTFN = strTFNnumber.trim();
        var intStringLen = strTFN.length;

        //rule 1: length --
        if (intStringLen < 7 || intStringLen > 9) {
            return false;
        }
        //rule 2: it should be number
        if (ato.spa.search.isInt(strTFN) == false) {
            return false;
        }

        //rule 3: check the algorithm
        var tfnArray = strTFN.split('');
        var intSumDigits = 0;
        var intCheckDigit = 0;
        for (var i = 0; i < intStringLen; i++) {
            var intValue = parseInt(tfnArray[i]);
            switch (i + 1) {
                case 1:
                    intSumDigits += intValue * 10;
                    break;
                case 2:
                    intSumDigits += intValue * 7;
                    break;
                case 3:
                    intSumDigits += intValue * 8;
                    break;
                case 4:
                    intSumDigits += intValue * 4;
                    break;
                case 5:
                    intSumDigits += intValue * 6;
                    break;
                case 6:
                    intSumDigits += intValue * 3;
                    break;
                case 7:
                    intSumDigits += intValue * 5;
                    break;
                case 8:
                    if (intStringLen > 8) {
                        intSumDigits += intValue * 2;
                    } else {
                        intCheckDigit = intValue;
                    }
                    break;
                case 9:
                    intCheckDigit = intValue;
                    break;
            }

        }//end for
        var sum = intSumDigits + intCheckDigit;
        if (sum == 11) {
            return true;
        } else if (sum > 11) {
            var intRemainder = intSumDigits % 11;
            var sumTemp = intRemainder + intCheckDigit;
            if (sumTemp == 0 || sumTemp == 11) {
                return true;
            } else {
                return false;
            }
        } else {
            return false;
        }
    };

    ato.spa.search.formatKeyMatch = function (htmlObj) {
        var text = htmlObj.text();
        //special replacement:  /definitions/%23  to /definitions/#
        text = text.replace("/definitions/%23", '/definitions/#');
        text = text.replace("/definitions%23", '/definitions/#')
        htmlObj.html(text);
    };

    ato.spa.search.formatDefition = function () {
        var allDefinition = $('.ato_definition_content');
        if (allDefinition.length == 0) {
            $('.definitions').each(function () {
                $(this).remove();
            });
        }
        var max = ato.spa.config.getConfigValue("ato_search_max_definition");
        for (var i = 0; i < allDefinition.length; i++) {
            var temp = $(allDefinition[i])
            if (i < max) {
                ato.spa.search.formatKeyMatch(temp);
            } else {
                temp.parent().remove();
            }
        }
    };

    ato.spa.replaceURLWithHtmlLinks = function (text) {
        var exp = /(\b(((https?|ftp|file|):\/\/)|www[.])[-A-Z0-9+&@#\/%?=~_|!:,.;]*[-A-Z0-9+&@#\/%=~_|])/ig;
        var extLinkImage = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAkAAAAJCAYAAADgkQYQAAAACXBIWXMAAA7DAAAOwwHHb6hkAAAAXklEQVQoU42QSw7AIAgF6cdreTE2XcDJOBgVKgl+Fp1EJb6BGA9twAQz9+pjKwUhX6WUR0QgVq3VAxMQ0e+AiGzYQAt7pWr5ImUhOH12ojX5mR+/SDt+Sbdt87+MALzn1F2KdrxITgAAAABJRU5ErkJggg==";
        return text.replace(exp, "<a href='$1' class='" + ato.spa.search.summary_link_css + "' target='_blank'>$1<img src='" + extLinkImage + "' class='" + ato.spa.search.summary_link_img_css + "'/></a>");
    };

    ato.spa.search.formatSummary = function () {
        $('.summary').each(function () {
            var origText = $(this).html();
            var newText = ato.spa.replaceURLWithHtmlLinks(origText);
            $(this).html(newText);
        });

        //add https
        $('.' + ato.spa.search.summary_link_css).each(function () {
            var url = $(this).attr("href");
            if (url.indexOf("http") != 0) {
                url = "https://" + url;
                $(this).attr("href", url);
            }
        });
    };

    ato.spa.search.formatVideoResult = function () {
        //		$('.' + ato.spa.search.constants.ato_video_link_class).each(function(){
        //			var iframe = $(this).parent().find('.' + ato.spa.search.constants.ato_video_iframe_class);
        //			iframe.css('width', '640px');
        //			var dialog = iframe.dialog({
        //			      autoOpen: false,
        //			      height: 372,
        //			      width: 640,
        //			      modal: true
        //			      close: ato.spa.search.videoClose
        //			    });
        //
        //			$(this).click(function(event)
        //				ato.spa.util.preventDefault(event);
        //				dialog.dialog( "open" );
        //			});
        //			//get the video url
        //
        //		});
		};


    ato.spa.search.videoClose = function () {
        this.contentWindow.postMessage('{"event":"command","func":"' + 'stopVideo' + '","args":""}', '*');
    };

    ato.spa.search.formatRecommendation = function () {
        var allDefinition = $('.ato_recommendation_content');
        var max = ato.spa.config.getConfigValue("ato_search_max_recommendation");
        for (var i = 0; i < allDefinition.length; i++) {
            var temp = $(allDefinition[i])
            if (i < max) {
                ato.spa.search.formatKeyMatch(temp);
            } else {
                temp.parent().remove();
            }
        }

        //quick links content
        var allQuickLinks = $('.quickSummary');
        for (var i = 0; i < allQuickLinks.length; i++) {
            var temp = $(allQuickLinks[i]);
            ato.spa.search.formatKeyMatch(temp);
        }
    	//ING
    	if(ato.spa.gsa.ga.newFrontend){
    		if(ato.spa.search.getCurrentFilter() != '' || ato.spa.search.current_site == ato.spa.config.getConfigValue('legaldb_collection')){
    			for (var i = 0; i < allDefinition.length; i++) {
        			$(allDefinition[i]).parent().hide();
        			//show 'No results...' if the only results are from definitions
        			$("#no_result_message_wrapper").show();
        		}
    		}
    	}
    };

    ato.spa.search.updateFilterForBannerSearch = function () {
        var legaldbSite = ato.spa.config.getConfigValue(pn_legaldb_collection);
        //var parametersURL = ato.spa.search.getLastSearchURL();
        var parametersURL = ato.spa.search.getLastRequestFromHash();
        var siteInURL = ato.spa.gsa.getParameterByNameInURL('site', parametersURL);
        if (siteInURL == '') {//for banner searc

            ato.spa.search.set_filter_from_hash = true;
        }
        if (ato.spa.search.set_filter_from_hash == false) {
            //			if(ato.spa.search.isQCSearch())
            //				ato.spa.search.setCurrentDateFilter("");
            //				ato.spa.search.current_dateFilterValue = ""
            //			}
            return;
        }
        if (siteInURL != '') {
        } else {
            siteInURL = ato.spa.GSAManager.getSite();
        }
        if (siteInURL == legaldbSite) {
            ato.spa.search.current_site = legaldbSite;
        } else {//check if there is gsacode filter
            //(ato_gsacode:210).(dc_date_filter:2015|dc_date_filter:0215)
            var partialFields = ato.spa.gsa.getParameterByNameInURL('partialfields', parametersURL);
            var generalId = ato.spa.search._getGeneralId();
            if (partialFields.indexOf(ato.spa.search.constants.DCTERMS_AtoGSACode) > 0) {
                var tempArray = partialFields.split(".");
                for (var i = 0; i < tempArray.length; i++) {
                    var temp = tempArray[i].replace("(", "").replace(")", "");
                    var gsacodeArray = temp.split("|");
                    //ato_gsacode:210|ato_gsacode:1006
                    for (var j = 0; j < gsacodeArray.length; j++) {
                        var gsacode = gsacodeArray[j].split(":")[1];
                        if (gsacode != generalId) {
                            ato.spa.search.setCurrentFilter(gsacode);
                            return;
                        }
                    }//end for
                }//end fo
            }
        }

        //date filter
        var currentDateFilter = ato.spa.search.getDefaultDateFilter();
        var preYearsDateFilter = ato.spa.search.getPreYearsDateFilter();
        var dateFilterValue = "";
		if(partialFields == undefined){
			partialFields = "";
		}
        if (partialFields.indexOf(currentDateFilter) > 0) {
            //current
            ato.spa.search.getDefaultDateFilter();
            dateFilterValue = "c";
        } else if (partialFields.indexOf(preYearsDateFilter) > 0) {
            //previous
            ato.spa.search.getPreYearsDateFilter();
            dateFilterValue = "p"
        } else {
            ato.spa.search.setCurrentDateFilter("");
        }
        ato.spa.search.current_dateFilterValue = dateFilterValue;

        //		if(ato.spa.search.isQCSearch())
        //			ato.spa.search.setCurrentDateFilter("");
        //			ato.spa.search.current_dateFilterValue = "";
        //
        ato.spa.search.set_filter_from_hash = false;
    };

    ato.spa.search.initFilter = function () {
        var listTimeout = 10;
        var filters = $('.searchFilters');

        //@@@@Step 1: set event handler for filter options
        $('#' + ato.spa.search.constants.ato_filter_label_id).change(function () {
            var option = $("option:selected", this);
            var gsacode = ato.spa.config.marketSegmentLookup(option.attr('ms'));
            var id = option.attr('id');
            if (id == ato.spa.search.constants.ato_filter_legal_db_id) {
                ato.spa.search.current_site = ato.spa.config.getConfigValue(pn_legaldb_collection);
                ato.spa.search.setCurrentFilter('');
                var parametersURL = ato.spa.search.getLastSearchURL();
                parametersURL = ato.spa.search.replaceParamInURL(parametersURL, "site", ato.spa.search.current_site);
                // ga trackin
                if (ato.spa.gsa.ga) {
                    ato.spa.gsa.ga.triggerDropdownFilter("filter", "Legal database");
                }
				//reset requiredfields
				parametersURL = ato.spa.search.replaceParamInURL(parametersURL, 'requiredfields', "");
				if(ato.spa.search.getCurrentFilter() == 'video'){
					ato.spa.search.setCurrentFilter("");
				}
                ato.spa.GSAManager.doSearch(parametersURL);
            } else if(id == ato.spa.search.constants.ato_filter_video_id){ //video search
    			//ga tracking
    			if(ato.spa.gsa.ga){
    				ato.spa.gsa.ga.triggerDropdownFilter("filter", option.attr('ms'));
    			}
    			var parametersURL = ato.spa.search.getLastSearchURL();
    			//reset partialfields
				parametersURL = ato.spa.search.replaceParamInURL(parametersURL, 'partialfields', "");
    			//reset requiredfields
				parametersURL = ato.spa.search.replaceParamInURL(parametersURL, 'requiredfields', "ato_content_source:youtube");
				ato.spa.search.setCurrentFilter("video");
				ato.spa.GSAManager.doSearch(parametersURL);
			} else {
                ato.spa.search.current_site = ato.spa.config.getDefaultSite()
                if(ato.spa.search.getCurrentFilter() == 'video'){
					ato.spa.search.setCurrentFilter("");
				}
				//ga tracking
                if (ato.spa.gsa.ga) {
                    ato.spa.gsa.ga.triggerDropdownFilter("filter", option.attr('ms'));
                }
                ato.spa.search.doFilter(gsacode);
            }
            ATO_SiteSearch.site = ato.spa.search.current_site;

        });//end change

        //@@@@Step 2: set event handler for date filter options
        $('#' + ato.spa.search.constants.ato_date_filter_label_id).change(function () {
            var option = $("option:selected", this);
            if (ato.spa.search.current_site == '') {
                ato.spa.search.current_site = ato.spa.config.getDefaultSite();
            }
            var year = option.attr('year');
            //ga trackin
            if (ato.spa.gsa.ga) {
                ato.spa.gsa.ga.triggerDropdownFilter("date_filter", option.text());
            }
            ato.spa.search.doDateFilter(year);
            ato.spa.search.current_dateFilterValue = year;
        });//end chang


        //set the init current date filter ADD
        if (ato.spa.search.firstLoad) {
            ato.spa.search.getDefaultDateFilter();
            ato.spa.search.firstLoad = false;
        }

        //@@@@Step 3: update UI for banner search
        ato.spa.search.updateFilterForBannerSearch();

        //@@@@Step 4: update UI: highlight and label
        ato.spa.search.updateFilterUI();
        ato.spa.search.updateDateFilterUI();
        //$(filters[0]).show();
        //@@@@Step 6: query filter data
        ato.spa.search.queryFilter();

		//@@@@Step 7: update new filter for desktop
	    ato.spa.search.upadteFilterDesktopUI();
    };

    ato.spa.search.setCurrentFilter = function (gsacode) {
        ato.spa.search.current_filter = gsacode;
    };

    ato.spa.search.getCurrentFilter = function () {
        return ato.spa.search.current_filter;
    };

    ato.spa.search.getDefaultDateFilter = function () {
        //return default dateFilter
        var d = new Date();
        var currentYear = d.getFullYear();
        var currentMonth = d.getMonth() + 1;
        var monthLength = currentMonth.toString().length;
        if (monthLength == 1) {
            currentMonth = "0" + currentMonth;
        }
        currentYearString = currentYear.toString();
        currentMonthYear = currentMonth + (currentYearString.substr(2));

        ato.spa.search.current_dateFilter = ato.spa.search.constants.DCTERMS_DcDateFilter + ':' + currentYearString + '|'
			+ ato.spa.search.constants.DCTERMS_DcDateFilter + ':' + currentMonthYear;
        return ato.spa.search.current_dateFilter;
    };

    ato.spa.search.getPreYearsDateFilter = function () {
        ato.spa.search.getDefaultDateFilter();
        ato.spa.search.current_dateFilter = "-" + ato.spa.search.current_dateFilter;
}

    ato.spa.search.setCurrentDateFilter = function (dateFilter) {
        ato.spa.search.current_dateFilter = dateFilter;
    };

    ato.spa.search.getCurrentDateFilter = function () {
        if (ato.spa.search.current_dateFilter == null || ato.spa.search.current_dateFilter == '') {
            //return ato.spa.search.getDefaultDateFilter(); //Changes made to cater All search result
            return "";
        } else {
            return ato.spa.search.current_dateFilter;
        }
    };

    ato.spa.search.doFilter = function (gsacode) {
        var tempCode = gsacode
        if (tempCode == null || tempCode == undefined) {
            tempCode = '';
        }
        ato.spa.search.setCurrentFilter(tempCode);
        var eventType = ato.spa.config.getConfigValue('ato_search_event_filter');
        ato.spa.GSAManager.setEventType(eventType);
        ato.spa.search._doFilter();
    };

    ato.spa.search.doDateFilter = function (year) {
        if (year == 'c') {//current
            ato.spa.search.getDefaultDateFilter();
        } else if (year == 'p') {//previous year
            ato.spa.search.getPreYearsDateFilter();
        } else {
            var temp = year;
            if (temp == null || temp == undefined || temp == '') {
                temp = '';
            } else {
                //build date filter
                var allMonths = new Array('01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12');
                temp = '';
                for (var i = 0; i < allMonths.length; i++) {
                    if (i > 0) {
                        temp += "|";
                    }
                    temp += ato.spa.search.constants.DCTERMS_DcDateFilter + ":" + allMonths[i] + year;
                }//end for
            }
            ato.spa.search.setCurrentDateFilter(temp);
        }
        var eventType = ato.spa.config.getConfigValue('ato_search_event_date_filter');
        ato.spa.GSAManager.setEventType(eventType);
        ato.spa.search._doFilter();
	};
    ato.spa.search._doFilter = function () {
        var parametersURL = ato.spa.search.getLastSearchURL();
        //reset the site
        parametersURL = ato.spa.search.replaceParamInURL(parametersURL, "site", ato.spa.search.current_site);
        parametersURL = parametersURL.replace("ato_content_source:youtube","");
        
        //reset search term
        if(ato.spa.search._isQueryChanged()){
        	var currentQuery = ato.spa.search._getQFromUI();
        	if(!parametersURL.startsWith('&')){
        		parametersURL = '&' + parametersURL;
        	}
        	parametersURL = ato.spa.search.replaceParamInURL(parametersURL, "q", currentQuery);
        }
		ato.spa.GSAManager.doSearch(parametersURL);
    };
    ato.spa.search._isQueryChanged = function(){
    	var currentQuery = ato.spa.search._getQFromUI();
	    var previousQuery = "";
	    if(ATO_SiteSearch != null){
	    	previousQuery = ATO_SiteSearch.query;
	    }
	    return previousQuery != currentQuery;
    };
    ato.spa.search.appendSite = function (parametersURL) {
        var result = parametersURL;
        var siteInURL = ato.spa.gsa.getParameterByNameInURL('site', parametersURL);
        
        if (siteInURL == '' && ato.spa.search.current_site != '') {
        	if(parametersURL.indexOf("site=&") >= 0){
        		result =  ato.spa.search.replaceParamInURL(result, "site", ato.spa.search.current_site);
        	}else{
        		result += "&site=" + ato.spa.search.current_site;
        	}
            
        }
        return result;
    };

    ato.spa.search.getLastSearchURL = function () {
        var parametersURL = ATO_SiteSearch.url.toString() + "&" + ato.spa.GSAManager.getOutputParams();
        if (parametersURL.indexOf("&q=") < 0 && parametersURL.indexOf("q=") != 0) {
            var q = ato.spa.search._getQFromUI();
            q = ato.spa.GSAManager.htmlEncode(q);
            parametersURL += "&q=" + q;
        }
        //append site
        parametersURL = ato.spa.search.appendSite(parametersURL);
        parametersURL = ato.spa.search._buildFilterParams(parametersURL);
        parametersURL = ato.spa.search.appendGetfields(parametersURL);
        return parametersURL;
    };

    ato.spa.search.replaceParamInURL = function (url, paramName, newValue) {
        return ato.spa.gsa.replaceParamInURL(url, paramName, newValue);
    };
    /**
	 * build filter parameter
	 */
    ato.spa.search._buildFilterParams = function (searchURL, noGSACode, noDateFilter) {
        var result = '';
        var filterValue = ''; //for partialfield
        var filterName = "partialfields";
        if (ato.spa.gsa.useRequiredFieldsForFilter) {
            if (ato.spa.config.getConfigValue('gsa_searchable') != '') {
                filterValue = '(' + ato.spa.config.getConfigValue('gsa_searchable') + ')'; //for requiredfiel
                filterName = "requiredfields";


			}
		}
        var dateFilter = ato.spa.search.getCurrentDateFilter();
        var gsacode = ato.spa.search.getCurrentFilter();
		if(noGSACode != true && gsacode == 'video'){
			if(filterValue != ''){
				filterValue += '.';
			}
			filterValue += '(ato_content_source:youtube)';
		}
        else if (noGSACode != true && gsacode != '') {
            if (filterValue != '') {
                filterValue += '.';
            }
            var generalId = ato.spa.search._getGeneralId();
            filterValue += "(" + ato.spa.search.constants.DCTERMS_AtoGSACode + ":" + gsacode + ")";
		}
		if(ato.spa.gsa.ga.newFrontend){
			noDateFilter = true;
		}
		if (noDateFilter == false && dateFilter != '') {
            if (filterValue != '') {
                filterValue += '.';
            }
            if (dateFilter.indexOf('-') == 0) {
                filterValue += "-(" + dateFilter.substring(1) + ")";
            } else {
                filterValue += "(" + dateFilter + ")";
            }
		}

        var currentFilterValue = ato.spa.gsa.getParameterByNameInURL(filterName, searchURL);
        var tempArray = currentFilterValue.split(".");
        var dctermsFilter = "";
        for (var i = 0; i < tempArray.length; i++) {
            if (tempArray[i].indexOf("(" + ato.spa.search.constants.DCTERMS_Identifier) == 0) {
                dctermsFilter = tempArray[i];

                break;
            } else if (tempArray[i].indexOf(ato.spa.search.constants.DCTERMS_Identifier) == 0) {
            	// when there is only one dcters filter and no () surrounding
            	dctermsFilter = tempArray[i];
            	
            	break;
            }
        }//end for
        if (dctermsFilter != '') {
            if (filterValue != '') {
                filterValue = dctermsFilter + "." + filterValue;
            } else {
                filterValue = dctermsFilter;
            }
        }
        result = ato.spa.search.replaceParamInURL(searchURL, filterName, filterValue);
        return result;
    };

    ato.spa.search.formatQ = function (q) {
        return q.replace(/\s*-/g, '-'); // remove space before '-';
    };

    //get search query
    ato.spa.search._getQFromUI = function () {
        var origQ = document.forms[0].q.value.trim();
        //store original query
        ATO_SiteSearch.origQuery = origQ;
        return ato.spa.search.formatQ(origQ);
    };

    ato.spa.search.initQueryForBannerSearch = function () {
        //original query for QC/NAT search
        //		var qnOrigQ = ato.spa.gsa.getParameterByName(ato.spa.search.constants.QC_NAT_ORIG_QUERY_PARAM);
        //		if(qnOrigQ != null && qnOrigQ != ''){
        //			ATO_SiteSearch.origQuery = qnOrigQ;
        //		};
        if (ato.spa.search.isBannerSearch()) {
            InitialiseStringBldrs();
            ATO_SiteSearch.origQuery = ato.spa.search.getOrigQueryFromHash();
            if (ATO_SiteSearch.origQuery != null && ATO_SiteSearch.origQuery != '') {
                ATO_SiteSearch.query = ATO_SiteSearch.origQuery;
                var resultPage = "";
                var dcIdentifier = ato.spa.search.constants.DCTERMS_Identifier;
                var dcNatNumber = ato.spa.search.constants.DCTERMS_NATNumber;
                var dcDateFilter = ato.spa.search.constants.DCTERMS_DcDateFilter;
                var primaryCollection = ato.spa.search._getConfigValue(pn_atogov_collection);
                var primarySearchable = ato.spa.search._getConfigValue(pn_gsa_searchable);
                var secondarySearchable = ato.spa.search._getConfigValue(pn_legal_nonindexed) + '.' + ato.spa.search._getConfigValue(pn_legal_searchable);
                IsNatOrQCSearch(dcNatNumber, dcIdentifier);
                //DetermineSearchYears(dcDateFilter);
                FormatRequiredField(primaryCollection, primarySearchable, secondarySearchable);
                BuildUrl(resultPage);
            }
        }
    };

    ato.spa.search.resetSearchCacheForHistoryLoad = function () {
        ATO_SiteSearch.origQuery = ato.spa.search.getOrigQueryFromHash();
        if (ATO_SiteSearch.origQuery != null && ATO_SiteSearch.origQuery != '') {
            ato.spa.search.resetQueryForQC();
        }
    };

    ato.spa.search.isBannerSearch = function () {
        var hashValue = location.hash;
        if (hashValue != null && hashValue != '') {
            var url = ato.spa.gsa.Base64.decode(hashValue);
            var flag = ato.spa.gsa.getParameterByNameInURL(ato.spa.search.constants.BANNER_SEARCH_PARAM, url);
            return flag == '1';
        }
        return false;
    };


    ato.spa.search.getOrigQueryFromHash = function () {
        //read value from hash
        var hashValue = location.hash;
        if (hashValue != null && hashValue != '') {
            //in the new change, the query parameter is stored in hash code
            var url = ato.spa.search.getLastRequestFromHash();
            var q = ato.spa.gsa.getParameterByNameInURL(ato.spa.search.constants.QC_NAT_ORIG_QUERY_PARAM, url);
            if (q == null || q == '') {
                q = ato.spa.gsa.getParameterByNameInURL('q', url);
            }
            return q;
        }
    };
    ato.spa.search.getLastRequestFromHash = function () {
        var hashValue = location.hash;
        if (hashValue != null && hashValue != '') {
            //in the new change, the query parameter is stored in hash code
            var url = ato.spa.gsa.Base64.decode(hashValue);
            return url;
        }
        return null;
    };

    ato.spa.search.resetQueryForQC = function () {
        if (ATO_SiteSearch.origQuery != '') {
            var dcIdentifier = ato.spa.search.constants.DCTERMS_Identifier;
            var dcNatNumber = ato.spa.search.constants.DCTERMS_NATNumber;
            if (_isNatOrQCSearch(dcIdentifier, dcNatNumber)) {
                //ato.spa.search.resetQuery();
                document.forms[0].q.value = ATO_SiteSearch.origQuery;
            }

        }
    };

    ato.spa.search.resetQuery = function () {
        if (ATO_SiteSearch.origQuery != '') {
            var currentQ = document.forms[0].q.value.trim();
            if (currentQ != ATO_SiteSearch.origQuery) {
                document.forms[0].q.value = ATO_SiteSearch.origQuery;
                //for NAT / QC cases.
                //1.     Pattern QCp-XXXXXX
                //2.     Pattern NATp-XXXXXX
                var pattern = new RegExp(/(QC|NAT)\s*-\S+/i);
                var res = pattern.test(ATO_SiteSearch.origQuery);
                if (res) { // is QC or NAT search with 'minus'
                    //show advised query div
                    $('#' + ato.spa.search.constants.GSA_ADVISED_LINKS_DIV_ID).show();

                    //show current search term
                    if (currentQ == '') {
                        currentQ = ATO_SiteSearch.origQuery.replace('-', ' ').replace(/\s+/g, ' ');
                    }
                    $('#' + ato.spa.search.constants.GSA_ADVISED_SPACE_TERM).text(currentQ);
                    //update the link for exclude search
                    var excludeQuery = ATO_SiteSearch.origQuery.replace('-', ' excluding ').replace(/\s+/g, ' ');
                    $('#' + ato.spa.search.constants.GSA_ADVISED_LINK_EXCLUDE_ID).text(excludeQuery);
                    $('#' + ato.spa.search.constants.GSA_ADVISED_LINK_EXCLUDE_ID).click(function (event) {
                        ato.spa.util.preventDefault(event);
                        var parametersURL = "&" + ato.spa.search.getLastSearchURL();
                        //replace

                        //add space for excluding feature
                        if (ATO_SiteSearch.origQuery.indexOf(' -') < 0) {
                            ATO_SiteSearch.origQuery = ATO_SiteSearch.origQuery.replace('-', ' -');
                        }
                        var query = ato.spa.GSAManager.htmlEncode(ATO_SiteSearch.origQuery);

                        //remove DCTERMS_identifier and in requiredfields and partialfields
                        InitialiseStringBldrs();
                        var dcDateFilter = ato.spa.search.constants.DCTERMS_DcDateFilter;
                        DetermineSearchYears(dcDateFilter);

                        //reset requiredfields
                        parametersURL = ato.spa.search.replaceParamInURL(parametersURL, 'requiredfields', ATO_SiteSearch.requiredFields.toString());

                        //reset partialfields:
                        parametersURL = ato.spa.search.replaceParamInURL(parametersURL, 'partialfields', ATO_SiteSearch.partialFields.toString());

                        parametersURL = ato.spa.search.replaceParamInURL(parametersURL, 'q', query);
                        ato.spa.GSAManager.doSearch(parametersURL);
                        return false;
                    });

                }
            }
        }
    };


    ato.spa.search.appendGetfields = function (url) {
        if (url.indexOf("&getfields=") < 0) {
            var result = url + "&getfields=*";
            //			var tempStr = ato.spa.config.getConfigValue('ato_search_description_meta_tag');
            //			if(tempStr != null && tempStr != ''){
            //				result += "." + tempStr;
            //			}
            return result
        } else {
            return url;
        }
    };

	//get filter count
	ato.spa.search.queryFilter = function(){
		if(ato.spa.config.showFilterCount()){
			if(ato.spa.gsa.ga.newFrontend){
				ato.spa.search.queryFilterNew();
			}else{
				ato.spa.search.queryFilterOld();
			}
		}

	};

    ato.spa.search.queryFilterOld = function () {
        //@TODO comments it now. it may be enabled in the future
        if (true) {
            return;
        }


        //sample request q=ato&client=ato_filter&output=xml_no_dtd&proxystylesheet=ato_filter&site=default_collection
        var q = ato.spa.search._getQFromUI();
        if (q == '') {
            return;
        }
        q = ato.spa.GSAManager.htmlEncode(q);
        var client = ato.spa.config.getFilterFrontend();
        var site = ato.spa.config.getDefaultSite();

        var parametersURL = "q=" + q + "&client=" + client + "&output=xml_no_dtd&proxystylesheet=" + client + "&site=" + site + "&requiredfields=" + ato.spa.config.getConfigValue('gsa_searchable');
        parametersURL = ato.spa.search._buildFilterParams(parametersURL, true);
        ato.spa.GSAManager.doSimpleSearch(parametersURL, ato.spa.search.updateAllFilter);
    };

	//	ato.spa.gsa.ga.newFrontend
	ato.spa.search.queryFilterNew = function(){
		//sample request q=ato&client=ato_filter&output=xml_no_dtd&proxystylesheet=ato_filter&site=default_collection
		//@@@@Step 1: query for filters except Legal DB
		var q = ato.spa.search._getQFromUI();
		if(q == ''){
			return;
		}
		q = ato.spa.GSAManager.htmlEncode(q);
		var client = ato.spa.config.getDefaultClient();
		var frontend = ato.spa.config.getFilterFrontend();
		var site = ato.spa.config.getDefaultSite();
		
		var dcIdentifier = ato.spa.search.constants.DCTERMS_Identifier;
        var dcNatNumber = ato.spa.search.constants.DCTERMS_NATNumber;
        
        var parametersURL = ato.spa.gsa.Base64.decode(location.hash);//ATO_SiteSearch.url.toString();
        if (parametersURL.indexOf("?") >=0) {
        	parametersURL = parametersURL.substr(parametersURL.indexOf("?") + 1);
        }
        parametersURL = ato.spa.search.replaceParamInURL(parametersURL, 'client', client);
        parametersURL = ato.spa.search.replaceParamInURL(parametersURL, 'proxystylesheet', frontend);
        parametersURL = ato.spa.search.replaceParamInURL(parametersURL, 'site', site);
        var partialfields = ato.spa.gsa.getParameterByNameInURL("partialfields", parametersURL);
    	partialfields = partialfields.replace(/\(ato_gsacode:[0-9]*\)/g, "");
    	partialfields = partialfields.replace(/^\.+|\.+$/g, '');
    	parametersURL = ato.spa.search.replaceParamInURL(parametersURL, 'partialfields', partialfields);
		
		ato.spa.GSAManager.doSimpleSearch(parametersURL, ato.spa.search.updateAllFilter);

		//@@@@Step 2: query Legal DB
		site = ato.spa.config.getConfigValue('legaldb_collection');
		parametersURL = ato.spa.gsa.Base64.decode(location.hash);//ATO_SiteSearch.url.toString();
		if (parametersURL.indexOf("?") >=0) {
        	parametersURL = parametersURL.substr(parametersURL.indexOf("?") + 1);
        }
        parametersURL = ato.spa.search.replaceParamInURL(parametersURL, 'client', client);
        parametersURL = ato.spa.search.replaceParamInURL(parametersURL, 'proxystylesheet', frontend);
        parametersURL = ato.spa.search.replaceParamInURL(parametersURL, 'site', site);
    	parametersURL = ato.spa.search.replaceParamInURL(parametersURL, 'partialfields', partialfields);
		
		ato.spa.GSAManager.doSimpleSearch(parametersURL, ato.spa.search.updateLegalDBFilter);
	};

	ato.spa.search.updateLegalDBFilter = function(data){
		var filters = $.parseJSON(data);
		var totalCount = filters["total_count"];
		if(totalCount == '' || totalCount == null){
			totalCount = 0;
		}
		if(filters){
			var options = $('.' + ato.spa.search.constants.ato_filter_desktop_class);

			for(var i = 0; i < options.length; i++){

				//<span class="searchTitle" title="All"></span><span class="searchCount"></span>
				var one = $(options[i]);
				var ms = one.attr('ms');
				var value = one.attr("value");
				var countSpan = $(one).find('.searchCount');
				if(value == '9'){//all
					var text = " (" + totalCount + ")";
					countSpan.text(text);
					ato.spa.search.syncFilterCount(9,countSpan.text());
					return;
				}
			}//end for
		}
	};

	ato.spa.search.syncFilterCount = function(filterValue, text){
		var options = $('.' + ato.spa.search.constants.ato_filter_class);

		for(var i = 0; i < options.length; i++){
			var one = $(options[i]);
			var value = one.attr('value');
			var label = one.attr('label');
			if(value == filterValue){
				one.text(label + text);
				return;
			}
		}//end for
	};

    //29-U Differentiate new and Updated Content
    ato.spa.search.updateDateTip = function () {
        $("." + ato.spa.search.constants.ato_date_class).each(function () {
            if ($(this).hasClass(ato.spa.search.constants.ato_date_social_class)) {
                return;
            }
            var dateString = $(this).text();
            var dateArray = dateString.split('-');
            var itemDate = new Date();
            itemDate.setYear(dateArray[0]);
            itemDate.setMonth(parseInt(dateArray[1]) - 1);
            itemDate.setDate(dateArray[2]);

            // Changed Date Format from yyyy-mm-dd to dd-M-yy if its valid date
            if (itemDate.toString() != "Invalid Date") {
                var formatmodifieddate = $.datepicker.formatDate('dd-M-yy', new Date(itemDate));
                $(this).html(formatmodifieddate);
            }

            var d = new Date();
            d.setMonth(d.getMonth() - 3);
            var altText = "This content has been recently added, reviewed or updated.";
            var altStyle = "<style> .ui-tooltip { background: white; width: 450px;border: 2px solid white;}</style>";
            $("body").append(altStyle);
            if (itemDate.getTime() > d.getTime()) {//in three months, show tips
                //show tips
                //var resultItem = $(this).closest('.' +  ato.spa.search.constants.GSA_SEARCH_RESULT_CSS);
                //var tips = "It is added or updated in three months";
                //resultItem.attr('title', tips);
                //resultItem.tooltip();
                var tipsTemplate = "<span class=\"updatedRecently\" title=\"" + altText + "\">New or updated</span><span>&nbsp;</span>";
                $(tipsTemplate).insertBefore($(this));
            }

            //set tooltip
            $(".updatedRecently").each(function () {
                $(this).tooltip({
                    position: { my: "right-100 bottom-20" }
                });
            });
        });
    };
    ato.spa.search.updateBreadcrumbs = function () {
        $("." + ato.spa.search.constants.ato_breadcrumbs_class).each(function () {
            var breadcrumb = $(this);
            //			var gsacode = breadcrumb.attr("gsacode");
            //			breadcrumb.click(function(){
            //				ato.spa.search.doFilter(gsacode);
            //			});
            //			var gsacodeDesc = ato.spa.config.marketSegmentLookup(gsacode);
            //@@@@Step 1: get the link
            var linkNode = breadcrumb.parent().find("a[ctype='c']");
            if (linkNode.length == 0) {
                linkNode = breadcrumb.parent().find("a[ctype='keymatch']");
            }
            var path = linkNode[0].pathname;

            var pathArray = path.split("/");
            var htmlContent = "";
            var endIndex = pathArray.length - 1;
            if (pathArray[pathArray.length - 1].length == 0) {
                endIndex--;
            }
            for (var i = 0; i < endIndex; i++) {
                if (pathArray[i] == '') {
                    continue;
                }
                htmlContent += "<li>" + pathArray[i] + "</li>";
            }

            breadcrumb.html(htmlContent);
        });
    };

    ato.spa.search.initYearFilterForOnebox = function (id) {
        var d = new Date();
        var currentYear = d.getFullYear();
        for (var year = currentYear; year >= 1993; year--) {
            var yearOption = '' + year + '/' + (year + 1);
            var option = '<option value="' + yearOption + '">' + yearOption + '</option>';
            $('#' + id).append(option);
        }
    };

    ato.spa.search.mcSearch = function () {
        //get parameters for media centre search
        var query = $('#' + ato.spa.search.constants.ato_mc_search_query_id).val().trim();
        var queryName = "searchterm";
        var yearFilter = $('#' + ato.spa.search.constants.ato_mc_search_year_filter_id).val();
        var url = ato.spa.config.getConfigValue('ato_mc_search_url');
        url += "&duration=" + yearFilter + "&" + queryName + "=" + query;
        window.location = url;
    };
    ato.spa.search.upadteMCSearchUI = function () {
        var q = ato.spa.search._getQFromUI();

        //@@@@Step 1: check the rul
        var results = q.match(ato.spa.search.constants.ato_mc_search_reg);
        //@@@@Step 2: show MC search UI
        if (results != null && results.length > 0) {
            //2.1 buid year filter data format 1993/1994, from 1993 to current year
            ato.spa.search.initYearFilterForOnebox(ato.spa.search.constants.ato_mc_search_year_filter_id);
            $("#" + ato.spa.search.constants.ato_mc_search_div_id).show();

            //@@@@Step 3: bind the event
            $("#" + ato.spa.search.constants.ato_mc_search_bt_id).click(function (event) {
                ato.spa.util.preventDefault(event);
                //do form search
                ato.spa.search.mcSearch();
                return false;
            });
            $("#" + ato.spa.search.constants.ato_mc_search_query_id).keypress(function (event) {
                if (event.keyCode == 13) {
                    ato.spa.util.preventDefault(event);
                    ato.spa.search.mcSearch();
                }
            });
        }
    };

    ato.spa.search.showMessageForAutoSearchDateFilter = function () {
        if (ato.spa.search.is_auto_search_for_date_filter) {
            var count = $("#ato_search_result_count").text().trim();
            if (count != '' && count != '0') {
                var messageHtml = "<span class=\"row\">No search results were found for the current year. Search results containing all years is now displayed</span>";
                $(".searchFilters").append(messageHtml);
            }
        }

        //set back auto search flag to false
        ato.spa.search.is_auto_search_for_date_filter = false;
    };

    ato.spa.search.ppSearch = function () {
        //get parameters for tax rates and codes search
        var query = $('#' + ato.spa.search.constants.ato_pp_search_query_id).val().trim();
        var queryName = "searchterm";
        if (ato.spa.search.isInt(query)) {
            queryName = "NatNumber";
        }
        var siteFilter = $('#' + ato.spa.search.constants.ato_pp_search_site_filter_id).val();
        var yearFilter = $('#' + ato.spa.search.constants.ato_pp_search_year_filter_id).val();
        var url = ato.spa.config.getConfigValue('ato_pp_search_url');
        url += "&duration=" + yearFilter + "&marketsegment=" + siteFilter + "&" + queryName + "=" + query;
        window.location = url;
    };
    ato.spa.search.upadtePPSearchUI = function () {
        var q = ato.spa.search._getQFromUI();

        //@@@@Step 1: check the rule
        var results = q.match(ato.spa.search.constants.ato_pp_search_reg);
        //@@@@Step 2: show TRC search UI
        if (results != null && results.length > 0) {
            //2.1 buid year filter data format 1993/1994, from 1993 to current year
            ato.spa.search.initYearFilterForOnebox(ato.spa.search.constants.ato_pp_search_year_filter_id);
            $("#" + ato.spa.search.constants.ato_pp_search_div_id).show();

            //@@@@Step 3: bind the event
            $("#" + ato.spa.search.constants.ato_pp_search_bt_id).click(function (event) {
                ato.spa.util.preventDefault(event);
                //do form search
                ato.spa.search.ppSearch();
                return false;
            });
            $("#" + ato.spa.search.constants.ato_pp_search_query_id).keypress(function (event) {
                if (event.keyCode == 13) {
                    ato.spa.util.preventDefault(event);
                    ato.spa.search.ppSearch();
                }
            });
        }
    };

    ato.spa.search.trcSearch = function () {
        //get parameters for tax rates and codes search
        var query = $('#' + ato.spa.search.constants.ato_trc_search_query_id).val().trim();
        var queryName = "searchterm";
        if (ato.spa.search.isInt(query)) {
            queryName = "NatNumber";
        }
        var siteFilter = $('#' + ato.spa.search.constants.ato_trc_search_site_filter_id).val();
        var yearFilter = $('#' + ato.spa.search.constants.ato_trc_search_year_filter_id).val();
        var url = ato.spa.config.getConfigValue('ato_trc_search_url');
        url += "&duration=" + yearFilter + "&marketsegment=" + siteFilter + "&" + queryName + "=" + query;
        window.location = url;
    };
    ato.spa.search.upadteTRCSearchUI = function () {
        var q = ato.spa.search._getQFromUI();

        //@@@@Step 1: check the rule
        var results = q.match(ato.spa.search.constants.ato_trc_search_reg);
        //@@@@Step 2: show TRC search UI
        if (results != null && results.length > 0) {
            //2.1 buid year filter data format 1993/1994, from 1993 to current year
            ato.spa.search.initYearFilterForOnebox(ato.spa.search.constants.ato_trc_search_year_filter_id);
            $("#" + ato.spa.search.constants.ato_trc_search_div_id).show();

            //@@@@Step 3: bind the event
            $("#" + ato.spa.search.constants.ato_trc_search_bt_id).click(function (event) {
                ato.spa.util.preventDefault(event);
                //do form search
                ato.spa.search.trcSearch();
                return false;
            });
            $("#" + ato.spa.search.constants.ato_trc_search_query_id).keypress(function (event) {
                if (event.keyCode == 13) {
                    ato.spa.util.preventDefault(event);
                    ato.spa.search.trcSearch();
                }
            });
        }
    };

    ato.spa.search.ctSearch = function () {
        //get parameters for form search
        var query = $('#' + ato.spa.search.constants.ato_ct_search_query_id).val().trim();
        var siteFilter = $('#' + ato.spa.search.constants.ato_ct_search_site_filter_id).val();
        var yearFilter = $('#' + ato.spa.search.constants.ato_ct_search_year_filter_id).val();
        var url = ato.spa.config.getConfigValue('ato_ct_search_url');
        url += "&duration=" + yearFilter + "&marketsegment=" + siteFilter + "&searchterm=" + query;
        window.location = url;
    };
    ato.spa.search.upadteCTSearchUI = function () {
        var q = ato.spa.search._getQFromUI();

        //@@@@Step 1: check the rule
        var results = q.match(ato.spa.search.constants.ato_ct_search_reg);
        //@@@@Step 2: show CT search UI
        if (results != null && results.length > 0) {
            //2.1 buid year filter data format 1993/1994, from 1993 to current year
            ato.spa.search.initYearFilterForOnebox(ato.spa.search.constants.ato_ct_search_year_filter_id);

            $("#" + ato.spa.search.constants.ato_ct_search_div_id).show();

            //@@@@Step 3: bind the event
            $("#" + ato.spa.search.constants.ato_ct_search_bt_id).click(function (event) {
                ato.spa.util.preventDefault(event);
                //do form search
                ato.spa.search.ctSearch();
                return false;
            });
            $("#" + ato.spa.search.constants.ato_ct_search_query_id).keypress(function (event) {
                if (event.keyCode == 13) {
                    ato.spa.util.preventDefault(event);
                    ato.spa.search.ctSearch();
                }
            });
        }
    };

    ato.spa.search.formSearch = function () {
        //get parameters for form search
        var query = $('#' + ato.spa.search.constants.ato_form_search_query_id).val().trim();
        var queryName = "searchterm";
        if (ato.spa.search.isInt(query)) {
            queryName = "NatNumber";
        }
        var siteFilter = $('#' + ato.spa.search.constants.ato_form_search_site_filter_id).val();
        var yearFilter = $('#' + ato.spa.search.constants.ato_form_search_year_filter_id).val();
        var url = ato.spa.config.getConfigValue('ato_form_search_url');
        url += "&duration=" + yearFilter + "&marketsegment=" + siteFilter + "&" + queryName + "=" + query;
        window.location = url;
    };
    ato.spa.search.upadteFormSearchUI = function () {
        var q = ato.spa.search._getQFromUI();

        //@@@@Step 1: check the rule
        var results = q.match(ato.spa.search.constants.ato_form_search_reg);
        //@@@@Step 2: show form search UI
        if (results != null && results.length > 0) {
            //2.1 buid year filter data format 1993/1994, from 1993 to current year
            ato.spa.search.initYearFilterForOnebox(ato.spa.search.constants.ato_form_search_year_filter_id);

            $("#" + ato.spa.search.constants.ato_form_search_div_id).show();

            //@@@@Step 3: bind the event
            $("#" + ato.spa.search.constants.ato_form_search_bt_id).click(function (event) {
                ato.spa.util.preventDefault(event);
                //do form search
                ato.spa.search.formSearch();
                return false;
            });
            $("#" + ato.spa.search.constants.ato_form_search_query_id).keypress(function (event) {
                if (event.keyCode == 13) {
                    ato.spa.util.preventDefault(event);
                    ato.spa.search.formSearch();
                }
            });
        }
    };

	ato.spa.search.upadteSearchBoxUI = function(){};

	ato.spa.search.upadteFilterDesktopUI = function(){
		$(".ato_filter_tab").each(function(){
			$(this).removeClass("active");
		});

		$("." + ato.spa.search.constants.ato_filter_desktop_class).each(function(){
			$(this).click(function(event){
				ato.spa.util.preventDefault(event);
				//get value
				var value = $(this).attr("value");
				//filter_label
				$('#' + ato.spa.search.constants.ato_filter_label_id).val(value).change();

			});
			var value = $('#' + ato.spa.search.constants.ato_filter_label_id).val();
			if($(this).attr("value") == value){
				$(this).parent().addClass("active");
			};
		});
	};

    ato.spa.search.validateABN = function (input) {
        var weights = new Array(10, 1, 3, 5, 7, 9, 11, 13, 15, 17, 19);
        //remove all non-digital
        var abn = input.replace(/[^\d]/g, "");
        // check length is 11 digits
        if (abn.length == 11) {
            var temp = abn.substring(0, 2);
            abn = '' + (parseInt(temp) - 10) + abn.substring(2);

            // apply ato check method
            var sum = 0;
            for (i = 0; i < weights.length ; i++) {
                sum += weights[i] * parseInt(abn.charAt(i));
            }
            return (sum % 89) == 0;
        }
        return false;
    };

    ato.spa.search.validateACN = function (input) {
        var weights = new Array(8, 7, 6, 5, 4, 3, 2, 1);

        //remove all non-digital
        var acn = input.replace(/[^\d]/g, "");

        // check length is 9 digits
        if (acn.length == 9) {
            // apply ato check method
            var sum = 0;
            for (var i = 0; i < weights.length; i++) {
                sum += weights[i] * parseInt(acn.charAt(i));
            }
            var check = (10 - (sum % 10)) % 10;
            return parseInt(acn.charAt(8)) == check;
        }
        return false;
    };

    ato.spa.search.ABNACNSearch = function () {
        var urlByACN = ato.spa.config.getConfigValue('ato_abr_search_by_acn_url');
        var urlByName = ato.spa.config.getConfigValue('ato_abr_search_by_name_url');
        var urlByABN = ato.spa.config.getConfigValue('ato_abr_search_by_abn_url');
        var url = "";
        var isABN = false;
        var isACN = false;
        //@@@@Step 1: get parameters for form search
        var query = $('#' + ato.spa.search.constants.ato_ABN_ACN_search_query_id).val().trim();

        //@@@@Step 2: check if it is ABN or ACN
        if (ato.spa.search.validateABN(query)) {
            isABN = true;
        } else if (ato.spa.search.validateACN(query)) {
            isACN = true;
        }

        //@@@@Step 3: do query:
        if (isABN) {
            url = urlByABN + query;
        } else if (isACN) {
            url = urlByACN + query;
        } else {
            url = urlByName + query;
        }
        window.open(url, '_blank');
    };
    ato.spa.search.upadteABNACNSearchUI = function () {
        var q = ato.spa.search._getQFromUI();



        //@@@@Step 1: check if it is ABN search
        var results = q.match(ato.spa.search.constants.ato_show_ABN_ACN_reg);

        //@@@@Step 2: show form search UI
        if (results != null && results.length > 0) {
            $("#" + ato.spa.search.constants.ato_ABN_search_div_id).show();

            //@@@@Step 3: bind the event
            $("#" + ato.spa.search.constants.ato_ABN_ACN_search_bt_id).click(function (event) {
                ato.spa.util.preventDefault(event);
                //do form search
                ato.spa.search.ABNACNSearch();
                return false;
            });

            $("#" + ato.spa.search.constants.ato_ABN_ACN_search_query_id).keypress(function (event) {
                if (event.keyCode == 13) {
                    ato.spa.util.preventDefault(event);
                    ato.spa.search.ABNACNSearch();
                    return false;
                }
            });
        }
    };

	ato.spa.search.isShowTaxCalculator = function(){
		return $("#" + ato.spa.search.constants.spa_tax_calculator_div_id).length > 0;
	};

	// tax calculator
	ato.spa.search.showTaxCalculator = function(){
		if(ato.spa.search.isShowTaxCalculator()){
			//@@@@Step 1: change the hash value
			location.hash = ato.spa.gsa.cleanHashValue(location.hash) + "/STC/questions";
			//@@@@Step 2: append spa div
			$("#" + ato.spa.search.constants.spa_tax_calculator_div_id).html('<div id="' + ato.spa.search.constants.spa_widget_div_id + '" class="spa"></div>');

			//@@@@Step 3: load spa widget js files
			//Please use below sample to add all js files required for SPA page render widget
			//ato.spa.gsa.loadjscssfile("http://tools.onigroup.com.au/gsa/tg/js/jquery-ui.js","js");
		}
	};

	ato.spa.search.showTaxCalculatorOld = function(){
		if($("#ato_tax_calculator_container").length > 0){
			//var wedget url: https://www.ato.gov.au/Calculators-and-tools/Host/?anchor=STC&anchor=STC#STC/questions
			var url = "https://www.ato.gov.au/Calculators-and-tools/Host/?anchor=STC&anchor=STC#STC/questions";

			//use iframe
			//var html = '<iframe width="100%" scrolling="no" height="1200" frameborder="0" mobilewidth="10" mobileheight="10" src="' +url +'" seamless="seamless" allowtransparency="true"></iframe>';
			//$("#ato_tax_calculator_container").html(html);

			//use div directly
			$.ajax({
				  url: url,
				  type: 'GET',
				  cache: true,
				  data: { },
				  success: function (data) {
					  //mainArea
					  //$("#ato_tax_calculator_container").html($(data).find("#mainArea").html());
					  //whole page
					  $("#ato_tax_calculator_container").html(data);
				  }//end success

				});
		}
	};

    //update the count of filter
    //sample data:
    //	{
    //		"ato_gsacode":{ "2216": "1962", "210": "1422"},
    //		"dc_date_filter":{ "0115 0215 0315 0415 0515 0615": "404", "0115 0215 0315 0415 0515 0615 0715 0815 0915 1015 1115 1215": "40"}}
    ato.spa.search.updateAllFilter = function (data) {
        var filters = $.parseJSON(data);
		var totalCount = filters["total_count"];
        if (filters) {
            ato.spa.search.updateFilter(filters[ato.spa.search.constants.DCTERMS_AtoGSACode], totalCount, filters);
            ato.spa.search.updateDateFilter(filters[ato.spa.search.constants.DCTERMS_DcDateFilter], totalCount);
        }
    };
    ato.spa.search.updateFilterUI = function () {
        var currentGsacode = ato.spa.search.getCurrentFilter()
        var options = $('.' + ato.spa.search.constants.ato_filter_class);

        for (var i = 0; i < options.length; i++) {
            var one = $(options[i]);
            var ms = one.attr('ms');
            var gsacode = ato.spa.config.marketSegmentLookup(ms);
            one.removeClass(ato.spa.search.constants.ato_filter_current_class);
            //change class/labe
            if (ato.spa.search.current_site != ato.spa.config.getConfigValue(pn_legaldb_collection)) {
				if(currentGsacode == "video" && one.attr('id') == ato.spa.search.constants.ato_filter_video_id){
					$("#filter_label").get(0).selectedIndex = i;
					break;
				}
				if (currentGsacode == gsacode && one.attr('id') != ato.spa.search.constants.ato_filter_legal_db_id) {
                    one.addClass(ato.spa.search.constants.ato_filter_current_class);
                    var label = one.text();
                    $("#filter_label").get(0).selectedIndex = i;
                    break;
                }
            }
        }//end for

        //update for legal db filter option
        if (ato.spa.search.current_site == ato.spa.config.getConfigValue(pn_legaldb_collection)) {
            $('#' + ato.spa.search.constants.ato_filter_legal_db_id).addClass(ato.spa.search.constants.ato_filter_current_class);
            $("#" + ato.spa.search.constants.ato_filter_legal_db_id).prop('selected', true);
        }

        $('#' + ato.spa.search.constants.ato_filter_label_id).show();
    };

    ato.spa.search.updateDateFilterUI = function () {
        var options = $('.' + ato.spa.search.constants.ato_dateFilter_class);
        for (var i = 0; i < options.length; i++) {
            var one = $(options[i]);
            one.removeClass(ato.spa.search.constants.ato_filter_current_class);
            var year = one.attr('year');
            //change class/label
            if (ato.spa.search.current_dateFilterValue == year) {
                one.addClass(ato.spa.search.constants.ato_filter_current_class);
                $("#date_filter_label").get(0).selectedIndex = i;
            }
        }//end for
        $('#' + ato.spa.search.constants.ato_date_filter_label_id).show();
    }

    //	"ato_gsacode":{ "2216": "1962", "210": "1422"
	ato.spa.search.updateFilter = function(filters, totalCount,jsonData){
		if(totalCount == null || totalCount == ''){
			totalCount = 0;
		}
		if(ato.spa.gsa.ga.newFrontend){
			ato.spa.search.updateFilterNew(filters, totalCount,jsonData);
		}else{
			ato.spa.search.updateFilterOld(filters, totalCount);
		}

	};

   ato.spa.search.updateFilterOld = function (filters) {
        if (filters == undefined) {
            filters = {};
        }
        var options = $('.' + ato.spa.search.constants.ato_filter_class);
        var currentGsacode = ato.spa.search.getCurrentFilter();

        for (var i = 0; i < options.length; i++) {
            // <li id="filter_individual" ms="Individuals" class="ato_filter"><a href="#">Individuals</a></li>
            var one = $(options[i]);
            var ms = one.attr('ms');
            var gsacode = ato.spa.config.marketSegmentLookup(ms);
            if (gsacode) {
                var count = filters[parseInt(gsacode)];
                if (count == null || count == undefined) {
                    count = 0;
                }
                var herfItem = $(one).find('a');
                var text = herfItem.html();
                var textBase = text.split("(")[0].trim();
                text = textBase + " (" + count + ")";
                //herfItem.html(text);
            }
        }//end for

    };

	//"ato_gsacode":{ "2216": "1962", "210": "1422"}
	ato.spa.search.updateFilterNew = function(filters, totalCount,jsonData){
		if(filters == undefined){
			filters = {};
		}
		var options = $('.' + ato.spa.search.constants.ato_filter_desktop_class);

		for(var i = 0; i < options.length; i++){
			//<span class="searchTitle" title="All"></span><span class="searchCount"></span>
			var one = $(options[i]);
			var ms = one.attr('ms');
			var value = one.attr("value");
			var countSpan = $(one).find('.searchCount');
			if(value == '9'){
				continue;
			}
			if(value == '0'){//all
				countSpan.text(" (" + totalCount + ")");
				ato.spa.search.syncFilterCount(value, countSpan.text());
				continue;
			}
			var generalGsacode = ato.spa.config.marketSegmentLookup("General");
			var generalCount = filters[parseInt(generalGsacode)];

			var gsacode = ato.spa.config.marketSegmentLookup(ms);
			var count = 0;
			if(gsacode){
				count = filters[parseInt(gsacode)];
				if(count == null || count == undefined){
					count = 0;
				}
			}
			if(ms != 'Videos'){
				//exclude 1006 for other filters
				//count = ato.spa.search.addGsaDynCount(generalCount,count);
			}else{
				var temp = jsonData["ato_content_source"];
				if(temp){
					count = temp["youtube"];
					count = ato.spa.search.addGsaDynCount("",count);
				}
			}

			countSpan.text(" (" + count + ")");
			ato.spa.search.syncFilterCount(value, one.text());
		}//end for

	};

	ato.spa.search.addGsaDynCount = function(a, b){
		var newA = (a + "").replace(">", "").trim();
		var newB = (b + "").replace(">", "").trim();
		if(newA == ''){
			newA = 0;
		}
		if(newB == ''){
			newB = 0;
		}
		return parseInt(newA) + parseInt(newB);
	};

    //update the count of filter
    //	"dc_date_filter":{ "0115 0215 0315 0415 0515 0615": "404", "0115 0215 0315 0415 0515 0615 0715 0815 0915 1015 1115 1215": "40"}}
    ato.spa.search.updateDateFilter = function (dateFilters) {
        if (dateFilters == undefined) {
            dateFilters = {};
        }
        //@@@@Step 1: calcualte the count
        var countByYear = new Array();
        var keys = Object.keys(dateFilters);
        //1.1 process one item by one
        for (var i = 0; i < keys.length; i++) {
            var key = keys[i];
            var tempArray = key.split(' ');
            var count = dateFilters[key];
            var tempCountByYear = new Array();
            //one meta tag
            for (var j = 0; j < tempArray.length; j++) {
                var monthYear = tempArray[j];
                var year = monthYear.substring(2, 4);
                var tempCount = tempCountByYear[year];
                if (tempCount == null || tempCount == undefined) {
                    tempCountByYear[year] = parseInt(count);
                }
            }//end for
            var oneKeys = Object.keys(tempCountByYear);
            for (var j = 0; j < oneKeys.length; j++) {
                var year = oneKeys[j];
                var tempCount = tempCountByYear[year];
                var existCount = countByYear[year];
                if (existCount == null || existCount == undefined) {
                    countByYear[year] = parseInt(tempCount);
                } else {
                    countByYear[year] = existCount + parseInt(tempCount);
                }
            }
        }//end for
        //@@@@Step 2: update the options
        var options = $('.' + ato.spa.search.constants.ato_dateFilter_class);
        for (var i = 0; i < options.length; i++) {
            //  <li class="ato_date_filter" year="14"><a href="#">FY14</a></li>
            var one = $(options[i]);
            var year = one.attr('year');
            //year == '' --> all
            if (year != '') {
                var count = countByYear[year];
                if (count == null || count == undefined) {
                    count = 0;
                }
                var herfItem = $(one).find('a');
                var text = herfItem.html();
                var textBase = text.split("(")[0].trim();
                text = textBase + " (" + count + ")";
                //herfItem.html(text)
            }
        }//end for
    };
    ato.spa.search.enableButtions = function () {
        $('#btnSearch0').removeAttr('disabled');
        $('input[type="submit"]').removeAttr('disabled');
        $('input[type="button"]').removeAttr('disabled');
    };
    ato.spa.search.disableButtions = function () {
        $('#btnSearch0').attr('disabled', 'disabled');
        $('input[type="submit"]').attr('disabled', 'disabled');
        $('input[type="button"]').attr('disabled', 'disabled');
    };
    /**
	 * disable all buttons on UI to avoid duplicating subumit.
	 * in the future, one new layer on the top can be used for this purpose
	 */
    ato.spa.search.startHourGlass = function (func) {
        //check if hour glass div exists
        if ($('#' + ato.spa.search.constants.hour_glass_div).length == 0) {
            var img = ato.spa.config.getConfigValue('ato_search_ui_hourglass_img');
            var divStr = '<div id="' + ato.spa.search.constants.hour_glass_div
				+ '" style="display:none;"><img src="' + img + '" id="hourGlass_img" style="display:block;position: absolute; top: 200px; left: 50%; visibility: visible; overflow: hidden; height: 32px; width: 32px" /></div>';
            ato.spa.GSAManager.getContainer().append(divStr);
        }
        ato.spa.search.disableButtions();
        $('body').css('cursor', 'wait');
        $('#' + ato.spa.search.constants.hour_glass_div).css({
            "position": "absolute",
            "top": "0px",
            "left": "0px",
            "margin-left": "1px",
            "margin-top": "1px",
            "background": "transparent",
            "background-color": "#FFFFFF",
            "height": function () { return ato.spa.GSAManager.getContainer().height(); },
            "filter": "alpha(opacity=30)",
            "-ms-filter": "progid:DXImageTransform.Microsoft.Alpha(Opacity=30)",
            "opacity": 0.3,
            "overflow": "hidden",
            "display": "block",
            "width": function () { return ato.spa.GSAManager.getContainer().width(); },
            "z-index": 9998
        })
        if (func != null && func != 'undefined') {
            setTimeout(func, 2000);
        }
    }

    ato.spa.search.stopHourGlass = function () {
        ato.spa.search.enableButtions()
        $('body').css('cursor', 'auto');
        $('#' + ato.spa.search.constants.hour_glass_div).css({
            "display": "none",
            "z-index": "-1"
        });
    };

    ato.spa.search.isQCSearch = function (q) {
        var query = "";
        if (q == null) {
            query = ato.spa.search._getQFromUI();
        }
        var qcNumber = getQCNumber(query);
        if (qcNumber == null || qcNumber == '') {
            return false;
        } else {
            try {
                parseInt(qcNumber);
                return true;
            } catch (e) {
                return false;
            }
        }
    };

    ato.spa.search.clickForQCSearch = function () {
        if (ato.spa.search.isQCSearch()) {
            //check result number
            var count = $("a[ctype='c']").length;
            if (count == 1) {
                $("a[ctype='c']")[0].click();
                return true;

            } else {
                return false;
            }
        }//
        return false;
    };

    ato.spa.search.hasResult = function () {
        return $("#gsa_no_result_q").length == 0;
    };
    ato.spa.search.searchAgain = function () {
        var q = ato.spa.search._getQFromUI();
		if(q != '' && q != ato.spa.config.getSearchPlaceholder()){
			if (ato.spa.search.hasResult() == false && ato.spa.search.current_dateFilterValue != ''){
				//do search again
				ato.spa.search.current_dateFilterValue = '';
				ato.spa.search.setCurrentDateFilter("");
				$("#btnSearch0").click();
				ato.spa.search.is_auto_search_for_date_filter = true;
				return true;
			}
        }
        return false;
    };

    ato.spa.search.postAction = function () {
        if (ato.spa.search.searchAgain()) {
            return false;
        }
        if (ato.spa.search.clickForQCSearch()) {
            return false;
        } else {
			ato.spa.search.upadteSearchBoxUI();
            ato.spa.search.upadteFormSearchUI();
            ato.spa.search.upadteABNACNSearchUI();
            ato.spa.search.upadteCTSearchUI();
            ato.spa.search.upadteTRCSearchUI();
            ato.spa.search.upadtePPSearchUI();
            ato.spa.search.upadteMCSearchUI();
            ato.spa.search.showMessageForAutoSearchDateFilter();
			ato.spa.search.showTaxCalculator();
            return true;
        }
    };

	$( window ).resize(function() {
			ato.spa.search.upadteSearchBoxUI();
		});
})();

// Toggles checkboxes when all ato is selected
$("#chk_all_ato").ready(function () {
    $("#chk_all_ato").click(function () {
        if ($("#chk_all_ato").attr('checked')) {
            $('#check_all').find('input[type=checkbox]').attr('checked', true);
        }
        else {
            $('#check_all').find('input[type=checkbox]').removeAttr('checked');

            var SegmentBox = $("input:checkbox.chkSegment");

            for (var i = 0; i < SegmentBox.length; i++) {
                if (SegmentBox[i].value == $("#hdn_market_value").val()) {
                    SegmentBox[i].checked = true;
                }
            }
        }
    });
});

$("#wrapper").ready(function () {
    $("#search_container").ready(function () {
        if ($("#search_container").exists()) {
            //BindBannerSearchEvents();
            //BindAdvancedLinkEvent();
        }
    });

    $("#adv_container").ready(function () {
        var Search = $("#adv_container");
        var Input = Search.find("input[type=text]");

        $("#check_all").ready(function () {
            var SegmentBox = $("input:checkbox.chkSegment");

            $(function () {
                var ATOCheck = $("#chk_all_ato");

                $(SegmentBox).click(function () {
                    var CheckedSegmentBox = $("input:checkbox:checked.chkSegment")
                    if (CheckedSegmentBox.length === SegmentBox.length) {
                        ATOCheck.attr('checked', true);
                    }
                    else {
                        ATOCheck.removeAttr('checked');
                    }
                });
            });

            $(Input).keyup(function handler(event) {
                Reset_Fields("#search_container", "default");
            }).keypress(function handler(event) {
                if (event.keyCode == 13) {
                    ato.spa.util.preventDefault(event);
                    (event.stopPropagation) ? event.stopPropagation() : event.cancelBubble = true;
                    Search.find("input[type = submit]").click();
                }
            });
        });
    });

    $("#results_container").ready(function () {
        var Search = $("#results_container");
        var Input = Search.find("input[type=text]")
        var default_value = Input.val();

        $(Input).focus(function () {
            if ($(this).val() == default_value || $(this).val() == "Search for...") { $(this).val(""); }
        }).blur(function () {
            if ($(this).val().length != 0) {
                $(this).addClass("inputBlurFilled");
            }
            if ($(this).val().length == 0) {
                $(this).val(default_value).removeClass("inputBlurFilled");
            }
        }).keyup(function handler(event) {
            Reset_Fields("#search_container", "default");
        });
    });

});

var ATO_SiteSearch = {
    partialFields: '',
    requiredFields: '',
    query: '',
    origQuery: '',
    site: '',
    url: '',
    strMarketSegment: ''
};

function InitialiseStringBldrs() {
    ATO_SiteSearch.partialFields = new StringBuilder();
    ATO_SiteSearch.requiredFields = new StringBuilder();
    ATO_SiteSearch.url = new StringBuilder();
}

function Parse_Banner_Search(defaultText, primaryCollection, secondaryCollection, primarySearchable, secondarySearchable, dcDateFilter, resultPage, atoHome, atoGsaCode, dcNatNumber, dcIdentifier) {
    //prevent form to submit on click of submit butto

	//just call new method..
    ato.spa.util.preventDefault(window.event);
    ato.spa.GSAManager._doTopSearch();
    return false;
}

function _isNatOrQCSearch(dcNatNumber, dcIdentifier) {
    try {
        if (ATO_SiteSearch.query.length > 0) {
            return ATO_SiteSearch.query.toUpperCase().indexOf("NAT") > -1 || ATO_SiteSearch.query.toUpperCase().indexOf("QC") > -1;
        } else {
            return ATO_SiteSearch.origQuery.toUpperCase().indexOf("NAT") > -1 || ATO_SiteSearch.origQuery.toUpperCase().indexOf("QC") > -1;
        }
    } catch (e) {
        return false;
    }

}

function IsNatOrQCSearch(dcNatNumber, dcIdentifier) {
    var Search = $("#adv_container");
    var allWords = '';
    var exactWords = '';
    if (Search.find("#txt_adv_all_words").exists()) {
        allWords = Search.find("#txt_adv_all_words").val();
    }
    if (Search.find("#txt_adv_exact_words").exists()) {
        exactWords = Search.find("#txt_adv_exact_words").val();
    }
    if (ATO_SiteSearch.query.toUpperCase().indexOf("NAT") > -1) {
        NatSearch($.trim(ATO_SiteSearch.query), dcNatNumber);
    }
    else if (ATO_SiteSearch.query.toUpperCase().indexOf("QC") > -1) {
        QCSearch($.trim(ATO_SiteSearch.query), dcIdentifier);
    }
    else if (allWords.toUpperCase().indexOf("NAT") > -1) {
        NatSearch($.trim(allWords), dcNatNumber);
    }
    else if (exactWords.toUpperCase().indexOf("NAT") > -1) {
        NatSearch($.trim(exactWords), dcNatNumber);
    }
    else if (allWords.toUpperCase().indexOf("QC") > -1) {
        QCSearch($.trim(allWords), dcIdentifier);
    }
    else if (exactWords.toUpperCase().indexOf("QC") > -1) {
        QCSearch($.trim(exactWords), dcIdentifier);
    }
    else {
        BasicString($.trim(ATO_SiteSearch.query), false);
    }
}

function NatSearch(inputStrQuery, dcNatNumber) {
    var strQuery = inputStrQuery.replace(/-/g, '');
    var index = strQuery.toUpperCase().indexOf("NAT");
    var natNumber = '';
    var charAfterNat = strQuery.charAt(index + 3);

    if (charAfterNat != ' ' & !isNaN(charAfterNat)) {
        natNumber = strQuery.substr(index + 3);
    }
    else if (charAfterNat == ' ' & !isNaN(strQuery.charAt(index + 4)) & strQuery.charAt(index + 4) != ' ') {
        natNumber = strQuery.substr(index + 4);
    }
    if (natNumber != '') {
        natNumber = natNumber.replace(/^0+/, '');
        ATO_SiteSearch.requiredFields.append(dcNatNumber);
        ATO_SiteSearch.requiredFields.append(":");
        ATO_SiteSearch.requiredFields.append(natNumber);
        ATO_SiteSearch.partialFields.clear();
        BasicString(strQuery, true); // use original
    }
    else {
        BasicString(strQuery, false);
    }
}

function getQCNumber(inputStrQuery) {
    var strQuery = inputStrQuery.replace(/-|\./g, '');
    var index = strQuery.toUpperCase().indexOf("QC");
    var qcNumber = '';
    if (index < 0) {
        return qcNumber;
    } else {
        var charAfterQC = strQuery.charAt(index + 2);
        if (charAfterQC != ' ') {
            qcNumber = strQuery.substr(index + 2);
        }
        else if (charAfterQC == ' ' & !isNaN(strQuery.charAt(index + 3)) & strQuery.charAt(index + 3) != ' ') {
            qcNumber = strQuery.substr(index + 3);
        }
        return qcNumber;
    }
}

function QCSearch(inputStrQuery, dcIdentifier) {
    var qcNumber = getQCNumber(inputStrQuery);
    if (qcNumber != null && qcNumber != '') {
        ATO_SiteSearch.partialFields.append(dcIdentifier);
        ATO_SiteSearch.partialFields.append(":");
        ATO_SiteSearch.partialFields.append(qcNumber);
        ATO_SiteSearch.requiredFields.clear();
        BasicString("QC " + qcNumber, true); // use original query
    }
    else {
        BasicString(inputStrQuery, false);
    }
}

function BasicString(strQuery, isNatOrQc) {
    var Search = $("#adv_container");
    var allWords = '';
    var exactWords = '';
    var orWords = '';
    var unwantedWords = '';
    if (Search.find("#txt_adv_all_words").exists()) {
        allWords = Search.find("#txt_adv_all_words").val();
    }
    if (Search.find("#txt_adv_exact_words").exists()) {
        exactWords = Search.find("#txt_adv_exact_words").val();
    }
    if (Search.find("#txt_adv_unwanted").exists()) {
        unwantedWords = Search.find("#txt_adv_unwanted").val();
    }

    if (isNatOrQc) {
        if ((allWords != '') && (strQuery != '')) {
            allWords = '';
        }
        if ((exactWords != '') && (strQuery != '')) {
            exactWords = '';
        }
        if ((unwantedWords != '') && (strQuery != '')) {
            unwantedWords = '';
        }
    }

    if (allWords != '') {
        ATO_SiteSearch.url.append("as_q=" + allWords);
    }

    if (exactWords != '') {
        if (ATO_SiteSearch.url.toString().length > 0) {
            ATO_SiteSearch.url.append("&as_epq=");
        }
        else {
            ATO_SiteSearch.url.append("as_epq=");
        }
        ATO_SiteSearch.url.append(exactWords);
    }


    if (($("input[id^='txt_adv_more_words']").val() !== undefined) && ($("input[id^='txt_adv_more_words']").val().length > 0)) {
        orWords = $("input[id^='txt_adv_more_words']").map(function () {
            return $(this).val();
        }).get().join('+');
    }

    if (orWords != '') {
        if (ATO_SiteSearch.url.toString().length > 0) {
            ATO_SiteSearch.url.append("&as_oq=");
        }
        else {
            ATO_SiteSearch.url.append("as_oq=");
        }
        ATO_SiteSearch.url.append(orWords);
    }

    if (unwantedWords != '') {
        if (ATO_SiteSearch.url.toString().length > 0) {
            ATO_SiteSearch.url.append("&as_eq=");
        }
        else {
            ATO_SiteSearch.url.append("as_eq=");
        }
        ATO_SiteSearch.url.append(unwantedWords);
    }
    if (ATO_SiteSearch.url.toString().length == 0) {
        ATO_SiteSearch.url.append("q=");
        if (isNatOrQc) {
            ATO_SiteSearch.url.append('');
            if (ATO_SiteSearch.origQuery != null && ATO_SiteSearch.origQuery != '') {
                ATO_SiteSearch.url.append('&' + ato.spa.search.constants.QC_NAT_ORIG_QUERY_PARAM + '=');
                ATO_SiteSearch.url.append(ATO_SiteSearch.origQuery);
            }

        } else {
            ATO_SiteSearch.url.append(escape(strQuery).replace(/ /), "+");
        }
    }
}

function FormatRequiredField(primaryCollection, primarySearchable, secondarySearchable) {

    var existingRequiredFields = ATO_SiteSearch.requiredFields.toString().length > 0;
    if (existingRequiredFields) {
        var newrequired = "(" + ATO_SiteSearch.requiredFields + ")"
        ATO_SiteSearch.requiredFields.clear();
        ATO_SiteSearch.requiredFields.append(newrequired);
    }

    if (ATO_SiteSearch.site == primaryCollection) {
        if (primarySearchable != '') {
            ATO_SiteSearch.requiredFields.append(".(");
            ATO_SiteSearch.requiredFields.append(primarySearchable)
            ATO_SiteSearch.requiredFields.append(")");
        }
    }
    else {
        ATO_SiteSearch.requiredFields.append(".(");
        ATO_SiteSearch.requiredFields.append(secondarySearchable);
        ATO_SiteSearch.requiredFields.append(")");
    }
}

function Reset_Fields(container, resetType) {
    var resetValue = "";
    if (resetType == "default") {
        resetValue = "Search for...";
    }
    $(container).find("input[type=text]").val(resetValue);
}

function checkEnterKeyPress (event, blnSingleMarketSegmentSearch, blnSearchWithinResults, iFormNum, strMarketSegment,
		primaryCollection, secondaryCollection, dcIdentifier, dcNatNumber, dcAtoGsaCode, primarySearchable,
		generalId, excludeGeneral, dcDateFilter, atoHome, legalNonIndexed, secondarySearchable) {
    if (event.keyCode == 13 && ato.spa.util.isValidSearchString(event.currentTarget.value)) {
        ato.spa.util.preventDefault(event);
        (event.stopPropagation) ? event.stopPropagation() : event.cancelBubble = true;
        Perform_Search(blnSingleMarketSegmentSearch, blnSearchWithinResults, iFormNum, strMarketSegment,
        		primaryCollection, secondaryCollection, dcIdentifier, dcNatNumber, dcAtoGsaCode, primarySearchable,
        		generalId, excludeGeneral, dcDateFilter, atoHome, legalNonIndexed, secondarySearchable);
    }
}

/**
 * sample parameters' values
 * @param blnSingleMarketSegmentSearch -- false
 * @param blnSearchWithinResults  -- false
 * @param iFormNum   -- 0
 * @param strMarketSegment -- 'ATO_Home'
 * @param primaryCollection  -- 'ATOGOV_Ektron'
 * @param secondaryCollection -- 'legaldb'
 * @param dcIdentifier -- 'DCTERMS_identifier'
 * @param dcNatNumber -- 'ato_reference_natNumber'
 * @param dcAtoGsaCode -- 'ato_gsacode'
 * @param primarySearchable -- '-ROBOTS:NOINDEX'
 * @param generalId -- '1006'
 * @param excludeGeneral -- '146,210'
 * @param dcDateFilter -- 'dc_date_filter'
 * @param atoHome -- 'ATO_Home'
 * @param legalNonIndexed -- '-ROBOTS:Index%20Only'
 * @param secondarySearchable -- '-ROBOTS:Not%20Searchable'
 */
function Perform_Search(blnSingleMarketSegmentSearch, blnSearchWithinResults, iFormNum, strMarketSegment,
		primaryCollection, secondaryCollection, dcIdentifier, dcNatNumber, dcAtoGsaCode, primarySearchable,
		generalId, excludeGeneral, dcDateFilter, atoHome, legalNonIndexed,
     secondarySearchable) {

    var Input = $("#results_container").find("input[type=text]");
    var legalDBChk = $("#results_container").find(".chkLegal")[iFormNum];
    var swrQuery = '';

    //--------------Setting cookie for Popup Survey-------
    var Numberlimit = 100;
    var LuckyNum = Math.floor((Math.random() * Numberlimit) + 1);
    var cname = "ATOGov_GoogleCookie"
    var exmins = 1; // equalent to 1 min
    var cvalue = $(".searchBar .q").val();
    if (LuckyNum == Numberlimit) {
        setCookie(cname, cvalue, exmins);
    }
    var currentQuery = ato.spa.search._getQFromUI();
    var previousQuery = "";
    if(ATO_SiteSearch != null){
    	previousQuery = ATO_SiteSearch.query;
    }
    var filterReset = resetFilterForFactedSearch(previousQuery, currentQuery);
    //--------------Setting cookie for Popup Survey--------
    ATO_SiteSearch.site = primaryCollection;
    ATO_SiteSearch.query = currentQuery;
    InitialiseStringBldrs();

    if (blnSearchWithinResults) {
        ATO_SiteSearch.query = $("#results_container").find(".as_q").val();
        swrQuery = $("#results_container").find("input[type=hidden]").val();
    }
    if ((ATO_SiteSearch.query == ato.spa.config.getSearchPlaceholder()) || (ATO_SiteSearch.query == '')) {
        if ($("#results_container").find(".search_error") > 0) {
            $("#results_container").find(".search_error")[0].style.display = '';
        }
	}

    else {

        if (blnSingleMarketSegmentSearch) {
            //this part is replaced by filter function
            //            var PartialFields = $("#results_container").find(".partialfields")
            //            var partialfields = PartialFields[iFormNum];
            //            var rdbPartialFields = partialfields
            //
            //            ATO_SiteSearch.site = primaryCollection;
            //            if (rdbPartialFields.checked)
            //                ATO_SiteSearch.strMarketSegment = strMarketSegment;
            //                ATO_SiteSearch.partialFields.append(rdbPartialFields.value)
            //                var includeGeneral = "true";
            //                var excludeGeneralArray = excludeGeneral.split(',');

		    //
            //                for (var i = 0; i < excludeGeneralArray.length; i++) {
            //                    if (rdbPartialFields.value == dcAtoGsaCode + ":" + excludeGeneralArray[i])
            //                        includeGeneral = "false";
            //
            //                }
            //                if (includeGeneral == "true") {
            //                    ATO_SiteSearch.partialFields.append("|")
            //                    ATO_SiteSearch.partialFields.append(dcAtoGsaCode);
            //                    ATO_SiteSearch.partialFields.append(":")
            //                    ATO_SiteSearch.partialFields.append(generalId);


			//                }
            //            }
        }
        else if (ato.spa.search.current_site == ato.spa.config.getConfigValue('legaldb_collection')) {
        	if (filterReset) {
        		ato.spa.search.current_site = ato.spa.config.getDefaultSite();
        		ATO_SiteSearch.strMarketSegment = atoHome;
                ATO_SiteSearch.partialFields.clear();
        	} else {
        		ATO_SiteSearch.strMarketSegment = atoHome;
                ATO_SiteSearch.site = secondaryCollection;
        	}
            
        }
        else {
            ATO_SiteSearch.strMarketSegment = atoHome;
            ATO_SiteSearch.partialFields.clear();
        }

        IsNatOrQCSearch(dcNatNumber, dcIdentifier);
        DetermineSearchYears(dcDateFilter);
        FormatRequiredField(primaryCollection, primarySearchable, secondarySearchable);

        if (blnSearchWithinResults) {
            var tempUrl = ATO_SiteSearch.url.toString().replace("q=", "as_q=");
            ATO_SiteSearch.url.clear();
            ATO_SiteSearch.url.append(tempUrl);
            ATO_SiteSearch.url.append("&q=");
            ATO_SiteSearch.url.append(escape(swrQuery.replace(/ /g, "+")));
        }
        //: check if no default value se
        if (ATO_SiteSearch.site == '') {
            ATO_SiteSearch.site = ato.spa.GSAManager.getSite();
        }



        BuildUrl("");
        var parametersURL = ATO_SiteSearch.url.toString() + "&" + ato.spa.GSAManager.getOutputParams();
        parametersURL = ato.spa.search.appendGetfields(parametersURL);
        parametersURL = ato.spa.search._buildFilterParams(parametersURL)
        //ga tracking
        if (ato.spa.gsa.ga) {
            ato.spa.gsa.ga.triggerInitialSearch(ATO_SiteSearch.query);
        }

        ato.spa.GSAManager.doSearch(parametersURL);
    }
}

function resetFilterForFactedSearch(previousQuery, currentQuery){
	if(ato.spa.gsa.ga.newFrontend){
		if(previousQuery != currentQuery){
			//set filter to 'All Result'
			ato.spa.search.setCurrentFilter("");
			return true;
		}
	}
	return false;
}

//function to set Cookie
function setCookie(cname, cvalue, exmins) {
    var dt = new Date();
    dt.setTime(dt.getTime() + (exmins * 60 * 1000));
    var expires = "expires=" + dt.toGMTString();
    document.cookie = cname + "=" + cvalue + "; " + expires;
}
function BuildUrl(resultsPage) {
    ATO_SiteSearch.url.insert(resultsPage, 0);
    ATO_SiteSearch.url.append("&site=");
    ATO_SiteSearch.url.append(ATO_SiteSearch.site);
    if (ato.spa.gsa.debug == false) {//For debug
        if (ato.spa.gsa.useRequiredFieldsForFilter == false) {
            ATO_SiteSearch.url.append("&partialfields=");
            ATO_SiteSearch.url.append(ATO_SiteSearch.partialFields.toString());
        }

        ATO_SiteSearch.url.append("&requiredfields=");
        ATO_SiteSearch.url.append(ATO_SiteSearch.requiredFields.toString());
    }
    ATO_SiteSearch.url.append("&ms=");
    ATO_SiteSearch.url.append(ATO_SiteSearch.strMarketSegment);
    ATO_SiteSearch.url.append("&start=0")
}

function DetermineSearchYears(dcDateFilter) {
    var prevyearsbox;
    var currentYear;
    var currentMonthYear;
    var currentMonth;
    var monthLength;
    var currentYearString;
    var d = new Date();

    var newpartial = new StringBuilder();

    var field = ATO_SiteSearch.partialFields;
    //    if(ato.spa.search.isQCSearch(ATO_SiteSearch.origQuery)){
    //    	return "";
    //    }
    if (ato.spa.gsa.useRequiredFieldsForFilter) {
        field = ATO_SiteSearch.requiredFields;
    }

    var partialsExist = field.toString().length > 0;

    if (partialsExist) {
        field.insert("(", 0);
        field.append(").");
    }
	if(ato.spa.gsa.ga.newFrontend){
    	return;
    }
	
    currentYear = d.getFullYear();
    currentMonth = d.getMonth() + 1;
    monthLength = currentMonth.toString().length;

    if (monthLength == 1)
        currentMonth = "0" + currentMonth;

    currentYearString = currentYear.toString();
    currentMonthYear = currentMonth + (currentYearString.substr(2));
    
    if ($("#chk_previous").exists() && $("#chk_previous")[0].checked) {
        field.append("-");
        field.append("(")
        field.append(dcDateFilter);
        field.append(":");
        field.append(currentYearString);
    }
    else {
        field.append("(")
        field.append(dcDateFilter);
        field.append(":");
        field.append(currentYearString);


	}
    field.append("|");
    field.append(dcDateFilter);
    field.append(":")
    field.append(currentMonthYear);
    field.append(")");


    //reset
    if (ato.spa.gsa.useRequiredFieldsForFilter) {
        ATO_SiteSearch.requiredFields = field;
    } else {
        ATO_SiteSearch.partialFields = field;
    }
}

function StringBuilder(value) {
    this.strings = new Array("");
    this.append(value);
}

StringBuilder.prototype.append = function (value) {
    if (value) {
        this.strings.push(value);
    }
}

StringBuilder.prototype.insert = function (value, index) {
    if (value) {
        this.strings.splice(index, 0, value);
    }
}

StringBuilder.prototype.clear = function () {
    this.strings.length = 1;
}

StringBuilder.prototype.toString = function () {
    return this.strings.join("");
}

jQuery.fn.exists = function () {
    return jQuery(this).length > 0;
};

