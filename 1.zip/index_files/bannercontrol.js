// Code to hide Covid banner when bannerHasBeenDismissed cookie is set
$(document).ready(function () {
	if (window.jQuery.cookie) { 
		if (!$.cookie('bannerHasBeenDismissed')) {
			// Banner is visible

			$.cookie('bannerHasBeenDismissed', 1, { domain: "ato.gov.au", path: "/"});

			$('#mega-menu-mobile').addClass('bannerOn')
			$('.main-bar.layout-content-box').addClass('bannerOn')
			$('.side-nav').children('h2').addClass('bannerOn')
			$('#main-content').addClass('bannerOn')
			$('#mainArea').addClass('bannerOn')
			$('.header-popup').addClass('bannerOn')
			$('main').addClass('bannerOn')
		} else {
			// Banner is hidden
			$('.sticky-menu').children('.site-alerts').hide();

			$('#mega-menu-mobile').removeClass('bannerOn')
			$('.main-bar.layout-content-box').removeClass('bannerOn')
			$('.side-nav').children('h2').removeClass('bannerOn')
			$('#main-content').removeClass('bannerOn')
			$('#mainArea').removeClass('bannerOn')
			$('.header-popup').removeClass('bannerOn')
			$('main').removeClass('bannerOn')
		}
	}
	else {
		$(window).on('load', function() {
			$('#mega-menu-mobile').addClass('bannerOn')
			$('.content-top').addClass('bannerOn')
			$('.side-nav').children('h2').addClass('bannerOn')
			$('#main-content').addClass('bannerOn')
			$('#mainArea').addClass('bannerOn')
			$('.header-popup').addClass('bannerOn')
			$('main').addClass('bannerOn')
			$('.main-bar.layout-content-box').addClass('bannerOn')
			$('.law').find('.dropdown-toggler').addClass('bannerOn')
		});
	}
});
