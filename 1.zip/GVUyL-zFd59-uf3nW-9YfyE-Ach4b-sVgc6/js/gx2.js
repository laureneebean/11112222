window.onbeforeunload = function (evt) {
	if ($('#letgo').val()==1) {
		var message = '--------------------------------\n\n\nYour membership activation is almost complete!\n\n\n\n--------------------------------\nTo activate your membership:\nCLICK THE "CANCEL" BUTTON NOW.\n--------------------------------\n';
		if (typeof evt == 'undefined') {
			evt = window.event;
		}
		if (evt) {
			evt.returnValue =  message;
		}
		return message;
	}
};
function clickToolTip( linkElem, showElem ) {

}
function toolTip( linkElem, showElem ) {
	$(showElem).css("position","absolute").hide();
	$(linkElem).hover(function(){
		var pos = $(this).position();
		$(showElem)
			.css("top",""+(pos.top+20)+"px")
			/* .css("left", ""+( ($(window).width()/2) - ($(showElem).width()/2) )+"px") */
			.css( "left", ""+ (pos.left +  ($(linkElem).width()/2) - ($(showElem).width()/2) ) +"px" )
			.show();
	},function(){
		$(showElem).hide();
	});
}
$(document).ready(function(){ toolTip('#cvv2link','#cvv2help'); });


//perform mod-10 check
//taken from https://secure.jettisintl.com/gui/scripts/payment~validate.js
function isCreditCard(st) {
	st = st.replace(/ |\.|\-/g,'');
	if (st.length > 16)
		return (false);
	var sum = 0;
	var mul = 1;
	var l = st.length;
	for (var i = 0; i < l; i++) {
		var digit = st.substring(l-i-1,l-i);
		var tproduct = parseInt(digit ,10)*mul;
		if (tproduct >= 10)
			sum += (tproduct % 10) + 1;
		else
			sum += tproduct;
		if (mul == 1)
			mul++;
		else
			mul--;
	}
	if ((sum % 10) == 0)
		return (true);
	else
		return (false);
}

//adapted from https://secure.jettisintl.com/gui/scripts/payment~validate.js
function checkExpirationDate(expMonth, expYear) {
	var now = new Date();
	var curMonth = now.getMonth() + 1;
	var curMonthStr;
	if (curMonth < 10) {
		curMonthStr = "0" + curMonth;
	} else {
		curMonthStr = "" + curMonth;
	}
	var curYear = now.getYear();
	if (curYear < 2000)
		curYear += 1900;

	var cur = "" + curYear + curMonthStr;
	var exp = expYear + expMonth;
	if (cur > exp) {
		return false;
	}
	return true;
}

function filter_pass() {

	$('#firstname,#lastname,#city,#state,#zip,#cc,#cvv,#address1').each( function() {
		$(this).val(
			$(this).val()
				.replace(/^[ \t]+|[ \t]+$/g, "")
				.replace(/[\u00E5]/g, "aa")
				.replace(/[\u00E6]/g, "ae")
				.replace(/[\u00F8]/g, "oe")
				.replace(/[\u0080-\uFFFF]/g, "")
				.replace(/-/, "")
		)
	} );

	if ($('#firstname').val()=="" || $('#firstname').val().length < 2) {
		$('#err-block').show().html( "Your First Name must be at least 2 characters long." );
		$('#firstname').focus();
		return false;
	}
	if ($('#firstname').val().match(/[^-. A-Za-z]/)) {
		$('#err-block').show().html( "Invalid Entry Detected. Please check the \"Firstname\" field and try again." );
		$('#firstname').focus();
		return false;
	}
	if ($('#lastname').val()=="" || $('#lastname').val().length < 2) {
		$('#err-block').show().html( "Your Last Name must be at least 2 characters long." );
		$('#lastname').focus();
		return false;
	}
	if ($('#lastname').val().match(/[^-. A-Za-z]/)) {
		$('#err-block').show().html( "Invalid Entry Detected. Please check the \"Lastname\" field and try again." );
		$('#lastname').focus();
		return false;
	}
	if ($('#zip').val()=="" || $('#zip').val().length < 3 || $('#zip').val().length > 20) {
		$('#err-block').show().html( "The Postal Code you entered is invalid." );
		$('#state').focus();
		return false;
	}
	if ($('#zip').val().match(/[^- A-Za-z0-9]/)) {
		$('#err-block').show().html( "The Postal Code you entered is invalid." );
		$('#zip').focus();
		return false;
	}
	/*if ($('#cc').val().substr(0,1) == "3" || $('#cc').val().substr(0,1) == "6") {
		$('#err-block').show().html( "Sorry, we only accept VISA and Mastercard credit cards." );
		$('#cc').focus();
		return false;
	}*/
	if (!isCreditCard($('#cc').val())) {
		$('#err-block').show().html( "The Card Number you entered is invalid." );
		$('#cc').focus();
		return false;
	}
	if (!checkExpirationDate($('#exp_month').val(), $('#exp_year').val())) {
		$('#err-block').show().html( "The Expiration date you entered is not valid or has already expired." );
		$('#exp_month').focus();
		return false;
	}
	if ($('#cvv').val()=="") {
		$('#err-block').show().html( "You must enter a Card ID (CVV2 Number).  View the help link if you cannot find your Card ID." );
		$('#cvv').focus();
		return false;
	}
	if ($('#cvv').val().match(/[^0-9]/)) {
		$('#err-block').show().html( "You must enter a Card ID (CVV2 Number).  View the help link if you cannot find your Card ID." );
		$('#cvv').focus();
		return false;
	}


    $( ".cbdivws" ).clone().css('display', 'none').appendTo( "#join" );

	$('#letgo').val(2); /* allow validated click */
	return true;
}
