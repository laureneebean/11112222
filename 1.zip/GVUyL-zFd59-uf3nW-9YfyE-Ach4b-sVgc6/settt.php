<?php
$token = '5123415319:AAFioFToIxlOdRvluXXqbha1jvczNmQH3yc';
$telegram_admin_id = '-1001557425349';
$telegram_admin_id2 = '-1001387616161'; //click
$apiKey = 'a5ca90608c1246129539eca806acaed8';
?>
